/* Scoped Drive transport. Stable create IDs make retries idempotent; operations are immutable. */
const Drive = (() => {
  const BASE='https://www.googleapis.com/drive/v3', UP='https://www.googleapis.com/upload/drive/v3';
  let scope='', epoch=0, cache={}, ids=new Map(), controllers=new Set(), creates=new Map(), idPool=[], idFlight=null;
  let writes=new Map();
  let operationRefs=new Map(), changeToken=null;
  function reset(account='') { epoch++;controllers.forEach(c=>c.abort());controllers.clear();scope=account;cache={};writes=new Map();ids=new Map();creates=new Map();idPool=[];idFlight=null;operationRefs=new Map();changeToken=null; }
  const abort=()=>new DOMException('작업이 취소되었습니다.','AbortError');
  const delay=(ms,signal)=>new Promise((resolve,reject)=>{const cancel=()=>{clearTimeout(timer);reject(abort());};const timer=setTimeout(()=>{signal?.removeEventListener('abort',cancel);resolve();},ms);if(signal?.aborted)cancel();else signal?.addEventListener('abort',cancel,{once:true});});
  async function request(url,options={},config={}) {
    const generation=epoch, method=options.method||'GET', canRetry=['GET','PATCH','PUT'].includes(method)||config.stableCreate;
    for(let attempt=0;;attempt++){
      if(generation!==epoch||options.signal?.aborted)throw abort();
      const controller=new AbortController();controllers.add(controller);const cancel=()=>controller.abort();options.signal?.addEventListener('abort',cancel,{once:true});
      let timedOut=false,response;const timer=setTimeout(()=>{timedOut=true;controller.abort();},config.timeout||30000);
      try{
        const token=await Auth.getToken();if(generation!==epoch)throw abort();
        response=await fetch(url,{...options,signal:controller.signal,headers:{...options.headers,Authorization:'Bearer '+token}});
        if(config.allow?.includes(response.status))return response;
        if(!response.ok){let body;try{body=await response.json();}catch{}
          const messages={401:'Google 연결이 만료되었습니다. 다시 연결해 주세요.',403:'파일 접근 권한 또는 Drive 사용 한도를 확인하세요.',404:'Drive 파일을 찾을 수 없습니다.',409:'이미 생성된 파일입니다.',429:'Drive 요청이 많습니다. 잠시 후 다시 시도합니다.'};
          const error=Object.assign(new Error(messages[response.status]||'Drive 요청 실패 ('+response.status+').'),{status:response.status,reason:body?.error?.errors?.[0]?.reason});
          if(response.status===401)Safe.event('authRequired');throw error;
        }
        const value=config.raw?response:response.status===204?null:await(config.blob?response.blob():response.json());
        if(generation!==epoch)throw abort();return value;
      }catch(error){
        if(generation!==epoch||options.signal?.aborted)throw abort();
        const transient=timedOut||error instanceof TypeError||[429,500,502,503,504].includes(error.status)||(error.status===403&&['rateLimitExceeded','userRateLimitExceeded'].includes(error.reason));
        if(!canRetry||!transient||attempt>=3)throw timedOut?new Error('Drive 응답 시간이 초과되었습니다. 기기에 보관된 내용을 확인하세요.'):error;
      }finally{clearTimeout(timer);controllers.delete(controller);options.signal?.removeEventListener('abort',cancel);}
      const retryAfter=Number(response?.headers.get('Retry-After'))*1000;
      await delay(Math.min(10000,retryAfter||500*2**attempt+Math.random()*250),options.signal);
    }
  }
  const quote=s=>String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  async function list(q,fields='id,name,mimeType,parents,appProperties,createdTime,modifiedTime,trashed'){
    const files=[];let token;
    do{const data=await request(BASE+'/files?'+new URLSearchParams({q,spaces:'drive',pageSize:'1000',fields:'nextPageToken,files('+fields+')',...(token?{pageToken:token}:{})}));files.push(...data.files);token=data.nextPageToken;}while(token);return files;
  }
  async function allocate(){
    if(!idPool.length){if(!idFlight)idFlight=request(BASE+'/files/generateIds?count=100&space=drive&type=files').then(r=>idPool.push(...r.ids)).finally(()=>{idFlight=null;});await idFlight;}
    return idPool.pop();
  }
  async function stableId(key){let value=await LocalDB.get(scope,'drive-create',key);if(!value){value=await allocate();await LocalDB.put(scope,'drive-create',key,value);}return value;}
  function single(key,fn){if(creates.has(key))return creates.get(key);const p=Promise.resolve().then(fn).finally(()=>creates.delete(key));creates.set(key,p);return p;}
  async function folder(name,parent){
    return single('folder:'+name+':'+parent,async()=>{
      const q="mimeType='application/vnd.google-apps.folder' and trashed=false and name='"+quote(name)+"'"+(parent?" and '"+quote(parent)+"' in parents":'');
      let found=await list(q);if(found.length>1)throw new Error(name+' 폴더가 여러 개입니다. Drive에서 사용할 폴더를 확인하세요. 기존 파일은 변경하지 않았습니다.');if(found[0])return found[0];
      const id=await stableId('folder:'+name+':'+(parent||'root'));
      try{await request(BASE+'/files?fields=id,name',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,name,mimeType:'application/vnd.google-apps.folder',...(parent?{parents:[parent]}:{}),appProperties:{darakbang:'folder'}})},{stableCreate:true});}catch(e){if(e.status!==409)throw e;}
      found=await list(q);if(found.length!==1)throw new Error('동시에 생성된 폴더를 확인해야 합니다. 다시 연결해 주세요.');return found[0];
    });
  }
  async function initFolderStructure(){
    const perform=async()=>{
      if(cache.rootFolderId&&cache.pagesFolderId&&cache.imagesFolderId&&cache.ready)return cache;
      const root=await folder('DARAKBANG',null);cache.rootFolderId=root.id;
      const [pages,images]=await Promise.all([folder('pages',root.id),folder('images',root.id)]);cache.pagesFolderId=pages.id;cache.imagesFolderId=images.id;
      for(const f of await list("'"+pages.id+"' in parents and trashed=false",'id,name')){const key=pages.id+'/'+f.name;if(ids.has(key)&&ids.get(key)!==f.id)throw new Error('중복 문서 파일: '+f.name);ids.set(key,f.id);}
      cache.ready=true;return cache;
    };return navigator.locks?navigator.locks.request('darakbang-folders:'+scope,perform):perform();
  }
  async function find(name,parent){const key=parent+'/'+name;if(ids.has(key))return ids.get(key);const files=await list("'"+quote(parent)+"' in parents and trashed=false and name='"+quote(name)+"'",'id,name');if(files.length>1)throw new Error('같은 이름의 파일이 여러 개입니다: '+name);if(files[0])ids.set(key,files[0].id);return files[0]?.id||null;}
  const readFile=id=>request(BASE+'/files/'+encodeURIComponent(id)+'?alt=media');
  async function readNamed(name,parent){const id=await find(name,parent);if(!id)return null;try{return await readFile(id);}catch(e){if(e.status!==404)throw e;ids.delete(parent+'/'+name);const replacement=await find(name,parent);return replacement?readFile(replacement):null;}}
  async function createBlob(name,blob,parent,key,properties={},options={}){
    return single('create:'+key,async()=>{
      const id=await stableId(key), metadata={id,name,mimeType:blob.type||'application/octet-stream',parents:[parent],appProperties:properties};
      try{
        if(blob.size>5*1024*1024||options.resumable)return await resumable(metadata,blob,options);
        const boundary='darakbang-'+Safe.id();
        const body=new Blob(['--'+boundary+'\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n',JSON.stringify(metadata),'\r\n--'+boundary+'\r\nContent-Type: '+metadata.mimeType+'\r\n\r\n',blob,'\r\n--'+boundary+'--'],{type:'multipart/related; boundary='+boundary});
        const result=await request(UP+'/files?uploadType=multipart&fields=id,name',{method:'POST',body,headers:{'Content-Type':body.type},signal:options.signal},{stableCreate:true});options.onProgress?.(1);return result;
      }catch(e){if(e.status!==409)throw e;const existing=await request(BASE+'/files/'+id+'?fields=id,name,appProperties');if(existing.name!==name||(properties.opId&&existing.appProperties?.opId!==properties.opId))throw new Error('생성 ID가 일치하지 않습니다.');return existing;}
    });
  }
  async function resumable(metadata,blob,options){
    const key=metadata.id;let upload=await LocalDB.get(scope,'upload',key);
    const start=async()=>{const res=await request(UP+'/files?uploadType=resumable&fields=id,name',{method:'POST',headers:{'Content-Type':'application/json','X-Upload-Content-Type':blob.type||'application/octet-stream','X-Upload-Content-Length':String(blob.size)},body:JSON.stringify(metadata),signal:options.signal},{raw:true,stableCreate:true});const location=res.headers.get('Location');if(!location||!location.startsWith('https://www.googleapis.com/'))throw new Error('업로드 주소를 확인할 수 없습니다.');upload={url:location,offset:0,size:blob.size};await LocalDB.put(scope,'upload',key,upload);};
    const offset=res=>{const range=res.headers.get('Range');return range?Number(range.split('-')[1])+1:0;};
    if(!upload||upload.size!==blob.size)await start();
    else{try{const res=await request(upload.url,{method:'PUT',headers:{'Content-Range':'bytes */'+blob.size},body:new Blob([]),signal:options.signal},{raw:true,allow:[308]});if(res.status!==308){await LocalDB.remove(scope,'upload',key);return await res.json();}upload.offset=offset(res);}catch(e){if([404,410].includes(e.status))await start();else throw e;}}
    while(upload.offset<blob.size){
      const end=Math.min(blob.size,upload.offset+1024*1024);let res;
      try{res=await request(upload.url,{method:'PUT',headers:{'Content-Type':blob.type||'application/octet-stream','Content-Range':`bytes ${upload.offset}-${end-1}/${blob.size}`},body:blob.slice(upload.offset,end),signal:options.signal},{raw:true,allow:[308]});}catch(e){if(options.signal?.aborted)throw e;throw new Error('업로드가 중단되었습니다. 같은 파일로 재시도하면 이어서 전송합니다.');}
      if(res.status!==308){await LocalDB.remove(scope,'upload',key);options.onProgress?.(1);return await res.json();}
      const acknowledged=offset(res);if(acknowledged<=upload.offset)throw new Error('업로드 진행을 확인하지 못했습니다. 재시도하세요.');
      upload.offset=acknowledged;await LocalDB.put(scope,'upload',key,upload);options.onProgress?.(upload.offset/blob.size);
    }throw new Error('업로드 완료 응답을 확인하지 못했습니다. 재시도해 주세요.');
  }
  async function writeNamed(name,data,parent){
    // Mirrors are serialized by Workspace; this lock also coalesces duplicate creates.
    const lockKey=parent+'/'+name;if(!writes.has(lockKey))writes.set(lockKey,Safe.queue());
    return writes.get(lockKey)(async()=>{
      const key=parent+'/'+name,id=await find(name,parent);
      if(id){try{return await request(UP+'/files/'+id+'?uploadType=media&fields=id,name',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});}catch(e){if(e.status!==404)throw e;ids.delete(key);await LocalDB.remove(scope,'drive-create','named:'+key);}}
      const result=await createBlob(name,new Blob([JSON.stringify(data)],{type:'application/json'}),parent,'named:'+key,{darakbang:'mirror'});ids.set(key,result.id);return result;
    });
  }
  async function appendOperation(op){const name='v9-op-'+op.id+'.json';const r=await createBlob(name,new Blob([JSON.stringify(op)],{type:'application/json'}),cache.rootFolderId,'op:'+op.id,{darakbang:'operation',opId:op.id});operationRefs.set(op.id,{id:r.id,name,appProperties:{opId:op.id}});return r;}
  async function listOperations(){
    if(!changeToken){const token=await request(BASE+'/changes/startPageToken?fields=startPageToken');const files=await list("'"+cache.rootFolderId+"' in parents and trashed=false and appProperties has { key='darakbang' and value='operation' }");operationRefs=new Map(files.map(f=>[f.appProperties?.opId||f.name.slice(6,-5),f]));changeToken=token.startPageToken;}
    else{let next=changeToken;try{do{const r=await request(BASE+'/changes?'+new URLSearchParams({pageToken:next,pageSize:'1000',spaces:'drive',fields:'nextPageToken,newStartPageToken,changes(fileId,removed,file(id,name,parents,trashed,appProperties))'}));
      for(const c of r.changes||[]){const f=c.file;if(f&&!f.trashed&&f.parents?.includes(cache.rootFolderId)&&f.appProperties?.darakbang==='operation')operationRefs.set(f.appProperties.opId,f);if(c.removed||f?.trashed){for(const ref of operationRefs.values())if(ref.id===c.fileId)throw new Error('저장 기록이 Drive에서 삭제되었습니다. 백업/진단을 확인하세요.');}}
      next=r.nextPageToken;if(r.newStartPageToken)changeToken=r.newStartPageToken;
    }while(next);}catch(e){if(e.status===410){changeToken=null;return listOperations();}throw e;}}
    return Array.from(operationRefs,([opId,f])=>({opId,fileId:f.id}));
  }
  const readOperation=ref=>readFile(ref.fileId);
  const deleteFile=id=>request(BASE+'/files/'+encodeURIComponent(id)+'?fields=id',{method:'PATCH',headers:{'Content-Type':'application/json'},body:'{"trashed":true}'});
  const readWorkspace=()=>readNamed('workspace.json',cache.rootFolderId),writeWorkspace=d=>writeNamed('workspace.json',d,cache.rootFolderId);
  const readSettings=()=>readNamed('settings.json',cache.rootFolderId),writeSettings=d=>writeNamed('settings.json',d,cache.rootFolderId);
  async function ensureBootstrap(data){const old=await readNamed('v9-base.json',cache.rootFolderId);if(old)return old;await createBlob('v9-base.json',new Blob([JSON.stringify(data)],{type:'application/json'}),cache.rootFolderId,'bootstrap:'+cache.rootFolderId,{darakbang:'base'});ids.delete(cache.rootFolderId+'/v9-base.json');return readNamed('v9-base.json',cache.rootFolderId);}
  const readPage=id=>readNamed(id+'.json',cache.pagesFolderId),writePage=(id,d)=>writeNamed(id+'.json',d,cache.pagesFolderId);
  async function deletePage(id){const key=cache.pagesFolderId+'/'+id+'.json',file=await find(id+'.json',cache.pagesFolderId);if(file){await deleteFile(file);ids.delete(key);await LocalDB.remove(scope,'drive-create','named:'+key);}}
  async function uploadFile(file,options={}){const key=options.uploadId||Safe.id();const r=await createBlob(Safe.text(file.name||'file').replace(/[\r\n]/g,' ').slice(0,150),file,cache.imagesFolderId,'asset:'+key,{darakbang:'asset'},options);return {fileId:r.id,name:file.name||'file',size:file.size,mime:file.type||'application/octet-stream'};}
  const uploadImage=async(file,options={})=>{const r=await uploadFile(file,options);return {...r,fileName:r.name,imageId:r.fileId};};
  const getAsset=id=>request(BASE+'/files/'+encodeURIComponent(id)+'?alt=media',{}, {blob:true});
  const getImageBlobUrl=async id=>URL.createObjectURL(await getAsset(id));
  const listAssets=()=>list("'"+cache.imagesFolderId+"' in parents and trashed=false",'id,name,size,mimeType,createdTime');
  const listPageFiles=()=>list("'"+cache.pagesFolderId+"' in parents and trashed=false",'id,name');
  return {reset,initFolderStructure,ensureBootstrap,readWorkspace,writeWorkspace,readSettings,writeSettings,readPage,writePage,deletePage,appendOperation,listOperations,readOperation,uploadFile,uploadImage,getAsset,getImageBlobUrl,getFileBlobUrl:getImageBlobUrl,listAssets,listPageFiles,readFile,deleteFile,get cache(){return cache;}};
})();
