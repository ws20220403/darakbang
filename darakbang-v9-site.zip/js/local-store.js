/**
 * local-store.js — localStorage 기반 데모/오프라인 백엔드
 *
 * Drive 와 동일한 인터페이스를 구현한다.
 * Google OAuth 없이도 앱 전체를 구동할 수 있는 "데모로 둘러보기" 모드.
 * 이미지는 dataURL 로 localStorage 에 저장한다(데모 한정).
 */

const LocalStore = (() => {

  const PREFIX = 'darakbang_demo_';
  const K = {
    workspace: PREFIX + 'workspace',
    settings:  PREFIX + 'settings',
    page:  (id) => `${PREFIX}page_${id}`,
    image: (id) => `${PREFIX}image_${id}`,
    seeded: PREFIX + 'seeded',
  };

  /* ---------- JSON 헬퍼 ---------- */
  function _get(key) {
    const raw = localStorage.getItem(key);
    if (raw == null) return null;
    try { return JSON.parse(raw); } catch { throw new Error('데모 데이터가 손상되었습니다. 원본을 초기화하지 않았습니다. 백업/진단에서 복구하세요.'); }
  }
  function _set(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
      return true;
    } catch (e) {
      throw new Error('데모 저장 공간(localStorage)이 가득 찼습니다. 일부 내용을 줄여주세요.');
    }
  }

  /* ---------- 초기화 + 샘플 시드 ---------- */
  const SEED_VERSION = '10';  // 샘플(사용법 등) 내용이 바뀌면 올림 → 데모 데이터 갱신 (v8: >→토글, 토글 Enter/글머리 반영)
  async function initFolderStructure() {
    // 사용자 문서가 있으면 샘플 버전과 관계없이 보존한다.
    if (localStorage.getItem(K.workspace) == null) {
      _seed();
      localStorage.setItem(K.seeded, SEED_VERSION);
    }
    return { demo: true };
  }

  async function readWorkspace() { return _get(K.workspace); }
  async function writeWorkspace(data) { _set(K.workspace, data); return { id: 'local-workspace' }; }

  async function readSettings() { return _get(K.settings); }
  async function writeSettings(data) { _set(K.settings, data); return { id: 'local-settings' }; }

  async function readPage(id) { return _get(K.page(id)); }
  async function writePage(id, data) { _set(K.page(id), data); return { id: `local-page-${id}` }; }
  async function deletePage(id) { localStorage.removeItem(K.page(id)); }

  /* New assets use IndexedDB Blobs; legacy data URLs remain readable. */
  async function uploadFile(file,options={}){
    if(options.signal?.aborted)throw new DOMException('업로드 중단','AbortError');
    if(file.size>2*1024*1024)throw new Error('데모 첨부파일은 최대 2MB입니다.');
    const scope=Storage.getScope(),fileId=options.uploadId?'asset-'+await Safe.hash(options.uploadId):Safe.id();
    const meta={fileId,name:file.name||'file',size:file.size,mime:file.type||'application/octet-stream'};
    await LocalDB.put(scope,'asset',fileId,{...meta,blob:file,createdAt:new Date().toISOString()});options.onProgress?.(1);return meta;
  }
  async function uploadImage(file,options={}){const r=await uploadFile(file,options);return{...r,imageId:r.fileId,fileName:r.name};}
  async function getImageBlobUrl(id){return URL.createObjectURL(await getAsset(id));}
  const getFileBlobUrl=getImageBlobUrl;

  /* ---------- 데모 샘플 데이터 ---------- */
  function _seed() {
    const now = new Date().toISOString();

    const workspace = {
      version: '2.0',
      pages: [
        { id: 'demo-guide',   title: Samples.USAGE_TITLE,             icon: Samples.USAGE_ICON, parentId: null, children: [], searchText: Samples.USAGE_SEARCH },
        { id: 'demo-welcome', title: '다락방 v9에 오신 걸 환영합니다', icon: '🏠', parentId: null, children: [], searchText: '데모 모드 드래그 손잡이 추가 블록 목록 코드 표 계산표 함수 파일 첨부 북마크 목차 체크리스트 저장 인용구' },
        { id: 'demo-ideas',   title: '아이디어 메모',                  icon: '💡', parentId: null, children: [], searchText: '' },
      ],
      rootPageOrder: ['demo-guide', 'demo-welcome', 'demo-ideas'],
    };

    const settings = {
      favorites: ['demo-guide'],
      theme: document.documentElement.getAttribute('data-theme') || 'light',
      sidebarWidth: 260,
      expandedPages: ['demo-welcome'],
    };

    const welcome = {
      id: 'demo-welcome', title: '다락방 v9에 오신 걸 환영합니다', icon: '🏠',
      coverImageId: null, parentId: null, createdAt: now, updatedAt: now,
      editorData: {
        time: Date.now(),
        blocks: [
          { type: 'header', data: { text: '다락방 v9 🏠', level: 1 } },
          { type: 'paragraph', data: { text: '이건 <b>데모 모드</b>예요. 데이터는 이 브라우저의 저장소에만 저장되고 구글 드라이브로 가지 않습니다. 마음껏 눌러보세요!' } },
          { type: 'callout', data: { text: '왼쪽 블록 앞의 <b>⠿ 손잡이</b>를 잡고 끌면 순서를 바꿀 수 있어요. <b>+</b> 버튼이나 <b>/</b> 를 누르면 추가할 블록을 한 화면에서 고를 수 있습니다.', icon: '✨', color: 'indigo' } },
          { type: 'header', data: { text: '편집기 주요 기능', level: 2 } },
          { type: 'list', data: { style: 'unordered', items: [
            { content: '<b>표에 함수</b> — 셀에 =SUM, =AVERAGE 같은 함수 (아래 예시)', items: [] },
            { content: '<b>파일</b> 첨부 — PDF·Word·Excel·hwp 등', items: [] },
            { content: '하위 페이지를 만들면 본문에 링크 자동 생성 + 순서 동기화(양방향)', items: [] },
            { content: '페이지 드래그&드롭 / ⋯ 위로·아래로 / 복제 / 내보내기 / 백업', items: [] },
          ] } },
          { type: 'paragraph', data: { text: '아래는 함수가 들어간 <b>표</b> 예시예요. 합계 칸을 눌러보면 <code class="inline-code">=SUM(...)</code> 수식이 보이고, 수식을 입력할 때 열(A·B·C)·행(1·2·3) 좌표가 살짝 나타납니다.' } },
          { type: 'table', data: { withHeadings: true, content: [
            ['항목', '1월', '2월', '합계'],
            ['매출', '100', '120', '=SUM(B2:C2)'],
            ['비용', '40', '55', '=SUM(B3:C3)'],
            ['평균', '=AVERAGE(B2:B3)', '=AVERAGE(C2:C3)', ''],
          ] } },
          { type: 'checklist', data: { items: [
            { text: '드래그로 블록 옮겨보기', checked: false },
            { text: '/ 입력해서 계산표·파일 추가해보기', checked: false },
            { text: '저장(Ctrl+S) 후 새로고침해보기', checked: true },
          ] } },
          { type: 'code', data: { code: 'function 다락방() {\n  return \"내 생각을 담는 공간\";\n}' } },
          { type: 'quote', data: { text: '작은 다락방에 생각을 차곡차곡.', caption: '다락방', alignment: 'left' } },
        ],
      },
    };

    const guide = {
      id: 'demo-guide', title: Samples.USAGE_TITLE, icon: Samples.USAGE_ICON,
      coverImageId: null, parentId: null, createdAt: now, updatedAt: now,
      editorData: Samples.usageEditorData(),
    };

    const ideas = {
      id: 'demo-ideas', title: '아이디어 메모', icon: '💡',
      coverImageId: null, parentId: null, createdAt: now, updatedAt: now,
      editorData: { time: Date.now(), blocks: [
        { type: 'paragraph', data: { text: '자유롭게 적어보세요…' } },
      ] },
    };

    _set(K.workspace, workspace);
    _set(K.settings, settings);
    _set(K.page('demo-welcome'), welcome);
    _set(K.page('demo-guide'), guide);
    _set(K.page('demo-ideas'), ideas);
  }

  /* ---------- 데모 데이터 초기화(선택) ---------- */
  async function resetDemo(){
    const scope=Storage.getScope();await LocalDB.clearScope(scope);await LocalDB.clearScope(scope+'@demo');
    Object.keys(localStorage).filter(k=>k.startsWith(PREFIX)).forEach(k=>localStorage.removeItem(k));
  }

  async function appendOperation(op) {
    const scope=Storage.getScope(), previous=await LocalDB.get(scope,'operation',op.id);
    if(previous&&JSON.stringify(previous)!==JSON.stringify(op)) throw new Error('중복 작업 ID의 내용이 다릅니다.');
    await LocalDB.put(scope,'operation',op.id,op); return {id:op.id};
  }
  async function ensureBootstrap(data) {const scope=Storage.getScope(),old=await LocalDB.get(scope,'bootstrap','v9');if(old)return old;await LocalDB.put(scope,'bootstrap','v9',data);return data;}
  async function listOperations() { return (await LocalDB.list(Storage.getScope(),'operation')).map(op=>({opId:op.id,fileId:op.id})); }
  const readOperation=ref=>LocalDB.get(Storage.getScope(),'operation',ref.opId);
  async function getAsset(id) {
    const stored=await LocalDB.get(Storage.getScope(),'asset',id);if(stored)return stored.blob;
    const data=localStorage.getItem(K.image(id));if(!data)throw new Error('파일을 찾을 수 없습니다.');
    return await (await fetch(data)).blob();
  }
  async function listAssets() { const assets=(await LocalDB.list(Storage.getScope(),'asset')).map(a=>({id:a.fileId,name:a.name,size:a.size,mimeType:a.mime,createdTime:a.createdAt}));return assets.concat(Object.keys(localStorage).filter(k=>k.startsWith(PREFIX+'image_')).map(k=>({id:k.slice((PREFIX+'image_').length),name:k.slice((PREFIX+'image_').length),createdTime:null}))); }
  async function listPageFiles() {return Object.keys(localStorage).filter(k=>k.startsWith(PREFIX+'page_')).map(k=>({id:k,name:k.slice((PREFIX+'page_').length)+'.json'}));}
  async function readFile(key) {return _get(key);}
  async function deleteFile(id) {await LocalDB.remove(Storage.getScope(),'asset',id);localStorage.removeItem(K.image(id));}

  return {
    initFolderStructure,
    readWorkspace, writeWorkspace,
    readSettings,  writeSettings,
    readPage, writePage, deletePage,
    uploadImage, getImageBlobUrl,
    uploadFile, getFileBlobUrl,
    resetDemo,
    ensureBootstrap, appendOperation, listOperations, readOperation, getAsset, listAssets, listPageFiles, readFile, deleteFile,
  };
})();
