/* Account-scoped durable drafts, operations and caches. No silent in-memory fallback. */
const LocalDB = (() => {
  let database, opening;
  async function open() {
    if (database) return database;
    if (!opening) opening = new Promise((resolve,reject)=>{
      const request=indexedDB.open('darakbang-v9',1);
      request.onupgradeneeded=()=>request.result.createObjectStore('records');
      request.onsuccess=()=>{database=request.result;database.onversionchange=()=>{database.close();database=null;opening=null;};resolve(database);};
      request.onerror=()=>reject(new Error('기기 보관함을 열 수 없습니다. 브라우저 저장 공간 설정을 확인하세요.'));
      request.onblocked=()=>reject(new Error('다른 탭을 닫은 후 다시 열어주세요.'));
    }).catch(e=>{opening=null;throw e;});
    return opening;
  }
  async function run(mode, fn) {
    const db=await open();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction('records',mode), store=tx.objectStore('records');let result;
      try { const request=fn(store);request.onsuccess=()=>{result=request.result;}; }
      catch(e){reject(e);return;}
      tx.oncomplete=()=>resolve(result);
      tx.onerror=tx.onabort=()=>reject(new Error('기기 보관에 실패했습니다. 저장 공간을 확인하고 내용을 내보내세요.'));
    });
  }
  const key=(scope,kind,id='')=>scope+'|'+kind+'|'+id;
  const get=(scope,kind,id='')=>run('readonly',s=>s.get(key(scope,kind,id)));
  const put=(scope,kind,id,value)=>run('readwrite',s=>s.put(value,key(scope,kind,id)));
  const remove=(scope,kind,id='')=>run('readwrite',s=>s.delete(key(scope,kind,id)));
  async function list(scope,kind) {
    const db=await open(), prefix=key(scope,kind);
    return new Promise((resolve,reject)=>{
      const values=[], tx=db.transaction('records','readonly');
      const req=tx.objectStore('records').openCursor(IDBKeyRange.bound(prefix,prefix+'\uffff'));
      req.onsuccess=()=>{const c=req.result;if(c){values.push(c.value);c.continue();}};
      tx.oncomplete=()=>resolve(values);tx.onerror=()=>reject(tx.error);
    });
  }
  async function clearScope(scope){const db=await open(),prefix=scope+'|';return new Promise((resolve,reject)=>{const tx=db.transaction('records','readwrite'),req=tx.objectStore('records').openCursor(IDBKeyRange.bound(prefix,prefix+'\uffff'));req.onsuccess=()=>{const c=req.result;if(c){c.delete();c.continue();}};tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
  async function putMany(scope,kind,entries){const db=await open();return new Promise((resolve,reject)=>{const tx=db.transaction('records','readwrite'),store=tx.objectStore('records');for(const[id,value]of entries)store.put(value,key(scope,kind,id));tx.oncomplete=()=>resolve();tx.onerror=tx.onabort=()=>reject(new Error('기기 인덱스 보관에 실패했습니다.'));});}
  return {open,get,put,remove,list,clearScope,putMany};
})();
