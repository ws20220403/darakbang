/* Recipe values are plain text. Scaling is derived; source quantities never change. */
const RecipeData = (() => {
  const MAX_INGREDIENTS = 200, MAX_STEPS = 100;
  function string(value, max, label) {
    if (value != null && !['string', 'number'].includes(typeof value)) throw new Error(label + ' 형식이 올바르지 않습니다.');
    const out = String(value ?? '');
    if (out.length > max) throw new Error(label + ' 입력 한도를 초과했습니다. 원본은 보존됩니다.');
    return out;
  }
  function rows(value, max, label) {
    if (!Array.isArray(value) || value.length > max || value.some(x => !x || typeof x !== 'object' || Array.isArray(x))) throw new Error(label + ' 형식 또는 개수 한도를 확인하세요.');
    return value;
  }
  function normalize(data = {}) {
    if (!data || typeof data !== 'object' || Array.isArray(data) || data.version != null && data.version !== 1) throw new Error('지원하지 않거나 손상된 레시피 형식입니다. 원본은 보존됩니다.');
    return {
      ...data, version: 1,
      name: string(data.name, 500, '메뉴명'), referenceUrl: string(data.referenceUrl, 2048, '참고 링크'),
      baseServings: string(data.baseServings ?? '2', 32, '기준 인분'), targetServings: string(data.targetServings ?? data.baseServings ?? '2', 32, '만들 인분'),
      minutes: string(data.minutes, 100, '조리 시간'), notes: string(data.notes, 20000, '메모'), isOpen: data.isOpen !== false,
      ingredients: rows(data.ingredients ?? [], MAX_INGREDIENTS, '재료').map(x => ({ ...x, name: string(x.name, 500, '재료명'), amount: string(x.amount, 256, '재료량'), unit: string(x.unit, 100, '단위'), note: string(x.note, 2000, '재료 메모'), checked: x.checked === true })),
      steps: rows(data.steps ?? [], MAX_STEPS, '조리 단계').map(x => ({ ...x, text: string(x.text, 10000, '조리 순서'), checked: x.checked === true })),
    };
  }
  function number(raw) {
    const value = String(raw ?? '').trim();
    let n;
    if (/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(value)) n = Number(value);
    else {
      const m = /^(?:(\d+)\s+)?(\d+)\s*\/\s*(\d+)$/.exec(value);
      if (!m || Number(m[3]) === 0) return null;
      n = Number(m[1] || 0) + Number(m[2]) / Number(m[3]);
    }
    return Number.isFinite(n) && n >= 0 && n <= 1e9 ? n : null;
  }
  function ratio(data) {
    const base = number(data.baseServings), target = number(data.targetServings);
    return base !== null && target !== null && base > 0 && target > 0 && base <= 10000 && target <= 10000 ? target / base : null;
  }
  function scaled(amount, data) {
    const n = number(amount), factor = ratio(data);
    if (n === null || factor === null) return null;
    const value = n * factor;
    if (!Number.isFinite(value) || value > 1e12 || value > 0 && value < 0.000001) return null;
    return Number(value.toFixed(6)).toLocaleString('en-US', { useGrouping: false, maximumFractionDigits: 6 });
  }
  function plain(data) {
    const d = normalize(data);
    return [d.name, d.referenceUrl, d.baseServings, d.targetServings, d.minutes, d.notes,
      ...d.ingredients.flatMap(x => [x.name, x.amount, x.unit, x.note]), ...d.steps.map(x => x.text)].filter(Boolean).join(' ');
  }
  function markdown(data) {
    const d = normalize(data);
    // Escape user text so a Markdown preview cannot turn stored text into active HTML.
    const esc = value => String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/[\\`*_[\]{}()#!|]/g, '\\$&').replace(/\r?\n/g, '  \n');
    let out = '### 🍳 ' + esc(d.name || '이름 없는 레시피') + '\n\n';
    if (d.referenceUrl) out += '참고 링크: ' + esc(d.referenceUrl) + '\n\n';
    out += '기준 ' + esc(d.baseServings) + '인분 · 만들 양 ' + esc(d.targetServings) + '인분' + (d.minutes ? ' · 조리 시간 ' + esc(d.minutes) + '분' : '') + '\n\n';
    out += '**재료**\n\n' + d.ingredients.map(x => {
      const calculated = scaled(x.amount, d), converted = ratio(d) !== 1 && calculated !== null ? ' → ' + calculated + ' ' + esc(x.unit) : '';
      return '- [' + (x.checked ? 'x' : ' ') + '] ' + esc(x.name) + ': ' + esc(x.amount) + ' ' + esc(x.unit) + converted + (x.note ? ' — ' + esc(x.note) : '');
    }).join('\n') + '\n\n**조리 순서**\n\n';
    out += d.steps.map((x, i) => (i + 1) + '. [' + (x.checked ? 'x' : ' ') + '] ' + esc(x.text)).join('\n') + '\n\n';
    if (d.notes) out += '**메모**\n\n' + esc(d.notes) + '\n\n';
    return out;
  }
  return { normalize, number, ratio, scaled, plain, markdown, MAX_INGREDIENTS, MAX_STEPS };
})();

class RecipeTool {
  static get toolbox() { return { title: '레시피', icon: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 9a4 4 0 0 1 4-7 4 4 0 0 1 6 0 4 4 0 0 1 4 7v4H5V9Zm1 4v7h12v-7M6 17h12"/></svg>' }; }
  static get isReadOnlySupported() { return true; }
  static get pasteConfig() { return false; }
  static get sanitize() { return { version: false, name: false, referenceUrl: false, baseServings: false, targetServings: false, minutes: false, notes: false, isOpen: false, ingredients: false, steps: false }; }
  constructor({ data, readOnly, block }) {
    this.data = RecipeData.normalize(Safe.clone(data || {})); this.readOnly = !!readOnly; this.block = block; this.dead = false;
  }
  _node(tag, text, cls) { const el = document.createElement(tag); if (text != null) el.textContent = text; if (cls) el.className = cls; return el; }
  _changed() {
    if (this.dead || this.readOnly) return;
    this.block?.dispatchChange(); Workspace.markDirty(); Safe.event('editorChanged');
  }
  _button(text, label, action) {
    const el = this._node('button', text); el.type = 'button'; el.setAttribute('aria-label', label || text);
    el.addEventListener('click', e => { e.stopPropagation(); if (!this.dead) action(); }); return el;
  }
  _field(object, key, label, max, multiline = false, placeholder = '') {
    const el = this._node(multiline ? 'textarea' : 'input');
    if (!multiline) el.type = 'text'; else el.rows = 2;
    el.value = object[key]; el.maxLength = max; el.readOnly = this.readOnly; el.setAttribute('aria-label', label); el.placeholder = placeholder;
    el.addEventListener('input', () => { if (this.readOnly || this.dead) return; object[key] = el.value; this._refresh(); this._changed(); });
    return el;
  }
  _label(text, input) { const label = this._node('label', text, 'recipe-field'); label.append(input); return label; }
  render() {
    const d = this.data, root = this._node('section', null, 'recipe-block'); this.el = root;
    root.setAttribute('aria-label', '레시피');
    const summary = this._node('div', null, 'recipe-summary');
    this.arrow = this._button('▾', '레시피 열고 닫기', () => { d.isOpen = !d.isOpen; this._refresh(); this._changed(); });
    this.arrow.className = 'recipe-arrow';
    const name = this._field(d, 'name', '메뉴명', 500, false, '메뉴명을 입력하세요'); name.className = 'recipe-name';
    this.badge = this._node('span', null, 'recipe-summary-info'); summary.append(this.arrow, this._node('span', '🍳'), name, this.badge);
    this.body = this._node('div', null, 'recipe-body'); this.body.id = 'recipe-' + Safe.id(); this.arrow.setAttribute('aria-controls', this.body.id);
    const meta = this._node('div', null, 'recipe-meta'), reference = this._field(d, 'referenceUrl', '참고 링크', 2048, false, 'https://…'); reference.inputMode = 'url';
    this.link = this._node('a', '참고 링크 열기'); this.link.target = '_blank'; this.link.rel = 'noopener noreferrer';
    this.linkMessage = this._node('span', null, 'recipe-hint');
    const referenceField = this._label('참고 링크', reference); referenceField.classList.add('recipe-reference'); referenceField.append(this.link, this.linkMessage); meta.append(referenceField);
    for (const [key, label, max] of [['baseServings', '기준 인분', 32], ['targetServings', '만들 인분', 32], ['minutes', '조리 시간(분)', 100]]) {
      const input = this._field(d, key, label, max); input.inputMode = 'decimal'; meta.append(this._label(label, input));
    }
    this.scaleMessage = this._node('p', null, 'recipe-hint');
    this.ingredientList = this._node('div', null, 'recipe-ingredients');
    this.stepList = this._node('ol', null, 'recipe-steps');
    this.body.append(meta, this.scaleMessage, this._node('h3', '필요한 것과 양'), this.ingredientList);
    if (!this.readOnly) this.body.append(this._button('＋ 재료 추가', null, () => this._add('ingredients')));
    this.body.append(this._node('h3', '조리 순서'), this.stepList);
    if (!this.readOnly) this.body.append(this._button('＋ 단계 추가', null, () => this._add('steps')));
    this.body.append(this._label('메모 · 대체 재료 · 보관 방법', this._field(d, 'notes', '레시피 메모', 20000, true, '다음에 만들 때 기억할 내용을 적어두세요.')));
    if (!this.readOnly) this.body.append(this._button('준비·완료 체크 초기화', null, () => {
      for (const x of [...d.ingredients, ...d.steps]) x.checked = false;
      this._renderRows(); this._refresh(); this._changed();
    }));
    root.append(summary, this.body);
    // Native inputs own selection, Enter, Tab, IME, clipboard and undo. Save still reaches App.
    root.addEventListener('keydown', e => {
      if (!e.target.matches('input,textarea,button')) return;
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 's') return;
      e.stopPropagation();
    });
    for (const type of ['paste', 'copy', 'cut', 'keyup', 'keypress']) root.addEventListener(type, e => { if (e.target.matches('input,textarea')) e.stopPropagation(); });
    root.addEventListener('drop', e => { if (e.target.matches('input,textarea')) { e.stopPropagation(); if (e.dataTransfer?.files?.length) e.preventDefault(); } });
    this._renderRows(); this._refresh(); return root;
  }
  _add(kind) {
    const max = kind === 'ingredients' ? RecipeData.MAX_INGREDIENTS : RecipeData.MAX_STEPS;
    if (this.data[kind].length >= max) { UI.toast((kind === 'ingredients' ? '재료는 ' : '단계는 ') + max + '개까지 추가할 수 있습니다.', 'info'); return; }
    this.data[kind].push(kind === 'ingredients' ? { name: '', amount: '', unit: '', note: '', checked: false } : { text: '', checked: false });
    this._renderRows(); this._refresh(); this._changed();
    (kind === 'ingredients' ? this.ingredientList : this.stepList).lastElementChild?.querySelector('input[type=text],textarea')?.focus();
  }
  _rowActions(kind, item, index, row) {
    if (this.readOnly) return;
    const actions = this._node('div', null, 'recipe-row-actions'), noun = kind === 'ingredients' ? '재료' : '단계';
    for (const [delta, text] of [[-1, '위로'], [1, '아래로']]) {
      const b = this._button(text, (index + 1) + '번 ' + noun + ' ' + text, () => {
        const list = this.data[kind], from = list.indexOf(item), to = from + delta;
        if (from < 0 || to < 0 || to >= list.length) return;
        [list[from], list[to]] = [list[to], list[from]]; this._renderRows(); this._refresh(); this._changed();
        (kind === 'ingredients' ? this.ingredientList : this.stepList).children[to]?.querySelector('input[type=text],textarea')?.focus();
      }); b.disabled = index + delta < 0 || index + delta >= this.data[kind].length; actions.append(b);
    }
    actions.append(this._button('삭제', (index + 1) + '번 ' + noun + ' 삭제', () => {
      const list = this.data[kind], at = list.indexOf(item); if (at < 0) return;
      list.splice(at, 1); this._renderRows(); this._refresh(); this._changed();
      const holder = kind === 'ingredients' ? this.ingredientList : this.stepList;
      const next = holder.children[Math.min(at, list.length - 1)];
      (next?.querySelector('input[type=text],textarea') || holder.nextElementSibling)?.focus();
    })); row.append(actions);
  }
  _check(item, label) {
    const input = this._node('input'); input.type = 'checkbox'; input.checked = item.checked; input.disabled = this.readOnly; input.setAttribute('aria-label', label);
    input.addEventListener('change', () => { if (this.readOnly || this.dead) return; item.checked = input.checked; this._refresh(); this._changed(); }); return input;
  }
  _renderRows() {
    this.ingredientList.replaceChildren(); this.stepList.replaceChildren(); this.amountOutputs = [];
    this.data.ingredients.forEach((item, i) => {
      const row = this._node('div', null, 'recipe-ingredient');
      row.append(this._check(item, (i + 1) + '번 재료 준비 완료'));
      const fields = this._node('div', null, 'recipe-ingredient-fields');
      for (const [key, label, max, placeholder] of [['name', '재료명', 500, '예: 양파'], ['amount', '양', 256, '예: 1/2, 약간'], ['unit', '단위', 100, '개, g, 큰술'], ['note', '재료 메모', 2000, '손질·대체 재료']]) {
        const field = this._label(label, this._field(item, key, (i + 1) + '번 ' + label, max, false, placeholder)); field.classList.add('recipe-ingredient-' + key); fields.append(field);
      }
      const output = this._node('span', null, 'recipe-calculated'); this.amountOutputs.push({ item, output }); fields.append(output); row.append(fields); this._rowActions('ingredients', item, i, row); this.ingredientList.append(row);
    });
    this.data.steps.forEach((item, i) => {
      const row = this._node('li', null, 'recipe-step'); row.append(this._node('span', String(i + 1), 'recipe-step-number'), this._check(item, (i + 1) + '번 단계 완료'), this._field(item, 'text', (i + 1) + '번 조리 순서', 10000, true, '조리 방법을 입력하세요. Enter로 줄을 바꿀 수 있습니다.'));
      this._rowActions('steps', item, i, row); this.stepList.append(row);
    });
  }
  _refresh() {
    if (!this.el || this.dead) return;
    const d = this.data, factor = RecipeData.ratio(d), url = Safe.url(d.referenceUrl, false);
    this.body.hidden = !d.isOpen; this.arrow.textContent = d.isOpen ? '▾' : '▸'; this.arrow.setAttribute('aria-expanded', String(d.isOpen));
    this.badge.textContent = d.steps.filter(x => x.checked).length + '/' + d.steps.length + '단계' + (d.minutes ? ' · ' + d.minutes + '분' : '');
    this.link.hidden = !url; if (url) this.link.href = url; else this.link.removeAttribute('href');
    this.linkMessage.textContent = d.referenceUrl && !url ? 'http:// 또는 https:// 주소를 입력하면 열 수 있습니다. 입력한 내용은 보관됩니다.' : '';
    this.scaleMessage.textContent = factor === null ? '인분은 0보다 크고 10,000 이하인 숫자로 입력하세요. 원래 양은 그대로 보관됩니다.' : '원래 재료량은 기준 인분의 양입니다. 숫자·분수만 환산하며 “약간” 등의 표현은 그대로 사용하세요.';
    for (const { item, output } of this.amountOutputs) {
      const value = RecipeData.scaled(item.amount, d);
      output.textContent = factor !== null && factor !== 1 && item.amount ? value !== null ? '만들 양: ' + value + (item.unit ? ' ' + item.unit : '') : '만들 양: ' + item.amount + (item.unit ? ' ' + item.unit : '') + ' (원문 · 자동 환산 안 함)' : '';
    }
  }
  save() { return RecipeData.normalize(Safe.clone(this.data)); }
  destroy() { this.dead = true; }
}
