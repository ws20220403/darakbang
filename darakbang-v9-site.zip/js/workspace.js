/* v9: a single immutable operation is the commit point. JSON mirrors are rebuildable. */
const Workspace = (() => {
  const sessionId=Safe.id();let draftRun=Safe.queue();
  let scope='',generation=0,current=null,clock=0,device='',online=true;
  let ws,settings,metas=new Map(),children=new Map(),versions=new Map(),heads=new Map(),seen=new Set(),refs=new Map(),fields=new Map();
  let archives=new Map();
  let pages=new Map(),edits=new Map(),run=Safe.queue(),mirrorRun=Safe.queue(),channel=null;
  const defaults=()=>({favorites:[],expandedPages:[]});
  const key=(a,b)=>a+'|'+b;
  const stampCompare=(a,b)=>a.clock-b.clock||a.id.localeCompare(b.id);
  const state=id=>{if(!edits.has(id))edits.set(id,{edit:0,ack:0,status:'saved'});return edits.get(id);};
  const currentHeads=id=>Array.from(heads.get(id)||[]).sort();
  const latest=id=>(versions.get(id)||[]).at(-1);
  const active=id=>{const m=metas.get(id);return m&&!m.deleted?m:null;};
  function reset(){generation++;channel?.close();channel=null;current=null;ws=null;settings=null;metas=new Map();children=new Map();versions=new Map();heads=new Map();seen=new Set();refs=new Map();fields=new Map();pages=new Map();archives=new Map();edits=new Map();run=Safe.queue();mirrorRun=Safe.queue();draftRun=Safe.queue();clock=0;}
  const guard=g=>{if(g!==generation)throw new DOMException('다른 작업공간으로 전환되었습니다.','AbortError');};
  function enqueue(task){const g=generation;return run(async()=>{guard(g);const result=await task(g);guard(g);return result;});}
  function remember(id,data){pages.delete(id);pages.set(id,Safe.clone(data));while(pages.size>32)pages.delete(pages.keys().next().value);}
  function rebuild(){
    children=new Map();for(const m of metas.values()){if(m.deleted)continue;const p=m.parentId||null;if(!children.has(p))children.set(p,[]);children.get(p).push(m);}
    for(const [parent,list]of children){const order=parent?metas.get(parent)?.children||[]:ws.rootPageOrder||[];const rank=new Map(order.map((id,i)=>[id,i]));list.sort((a,b)=>(rank.get(a.id)??Number.MAX_SAFE_INTEGER)-(rank.get(b.id)??Number.MAX_SAFE_INTEGER)||a.id.localeCompare(b.id));}
    ws.pages=Array.from(metas.values());
  }
  function validateWorkspace(value){
    if(!value||!Array.isArray(value.pages))throw new Error('워크스페이스 형식이 손상되었습니다. 기존 파일을 덮어쓰지 않았습니다.');
    const ids=new Set();for(const m of value.pages){if(!m||typeof m.id!=='string'||!/^[\w.-]+$/.test(m.id)||ids.has(m.id))throw new Error('중복 또는 잘못된 문서 ID가 있습니다. 원본 백업을 확인하세요.');ids.add(m.id);}
    return Safe.clone(value);
  }
  function normalizeMeta(m){return {...m,title:Safe.text(m.title).slice(0,500),icon:Safe.text(m.icon||'📄').slice(0,40),parentId:m.parentId||null,children:Array.from(new Set(Array.isArray(m.children)?m.children:[]))};}
  function loadSnapshot(s){
    ws=validateWorkspace(s.ws);settings={...defaults(),...s.settings};metas=new Map(ws.pages.map(m=>[m.id,normalizeMeta(m)]));
    archives=new Map(s.archives||[]);versions=new Map(s.versions||[]);heads=new Map((s.heads||[]).map(([id,values])=>[id,new Set(values)]));seen=new Set(s.seen||[]);refs=new Map(s.refs||[]);fields=new Map(s.fields||[]);clock=s.clock||0;rebuild();
  }
  async function checkpoint(){return LocalDB.put(scope,'state','latest-v9.2',{ws,settings,archives:Array.from(archives),versions:Array.from(versions),heads:Array.from(heads,([id,s])=>[id,Array.from(s)]),seen:Array.from(seen),refs:Array.from(refs),fields:Array.from(fields),clock});}
  async function init(){
    reset();scope='';const g=generation;await LocalDB.open();device=localStorage.getItem('darakbang_device')||Safe.id();localStorage.setItem('darakbang_device',device);
    const accountScope=Storage.getScope();
    try{
      await Storage.initFolderStructure();guard(g);scope=accountScope+'@'+(Storage.isDemo()?'demo':Drive.cache.rootFolderId);
      await LocalDB.put(accountScope,'last-root','scope',scope);
      const saved=await LocalDB.get(scope,'state','latest-v9.2')||await LocalDB.get(scope,'state','latest');
      if(saved)loadSnapshot(saved);
      else{
        const [oldWs,oldSettings]=await Promise.all([Storage.readWorkspace(),Storage.readSettings()]);
        const base={schemaVersion:3,workspace:validateWorkspace(oldWs||{version:'2.0',pages:[],rootPageOrder:[]}),settings:oldSettings||defaults(),createdAt:new Date().toISOString()};
        await LocalDB.put(scope,'migration','original',base);
        const remote=await Storage.ensureBootstrap(base);guard(g);loadSnapshot({ws:remote.workspace,settings:remote.settings});
      }
      await refreshInternal(g);online=true;
    }catch(e){
      guard(g);if(e.status===403||e.status===404||/손상|중복|여러 개|삭제되었습니다|일치|지원하지/.test(e.message))throw e;
      const cachedScope=await LocalDB.get(accountScope,'last-root','scope');const cached=cachedScope&&(await LocalDB.get(cachedScope,'state','latest-v9.2')||await LocalDB.get(cachedScope,'state','latest'));
      if(!cached)throw e;scope=cachedScope;loadSnapshot(cached);online=false;Safe.event('syncStatus',{message:'기기에 보관된 문서 · 연결 후 동기화',state:'offline'});
    }
    guard(g);ws.version='3.0';
    if(typeof BroadcastChannel!=='undefined'){channel=new BroadcastChannel('darakbang:'+scope);channel.onmessage=()=>{refresh().catch(()=>{});};}
    if(!getAllPagesMeta().length&&online&&typeof Samples!=='undefined')await createPage(null,{title:Samples.USAGE_TITLE,icon:Samples.USAGE_ICON,editorData:Samples.usageEditorData()});
    return {workspace:ws,settings};
  }
  function apply(op){
    if(seen.has(op.id))return;
    if(![3,4].includes(op.schemaVersion)||typeof op.id!=='string'||!Number.isSafeInteger(op.clock)||!Array.isArray(op.meta)||!Array.isArray(op.pages))throw new Error('지원하지 않거나 손상된 저장 기록입니다.');
    for(const x of op.meta)if(!x||typeof x.id!=='string'||!x.patch||typeof x.patch!=='object')throw new Error('저장 기록의 문서 정보가 손상되었습니다.');
    for(const x of op.archives||[])Safe.page(x.data);
    for(const x of op.pages){Safe.page(x.data);if(x.bases&&!Array.isArray(x.bases))throw new Error('버전 계보가 손상되었습니다.');}
    const stamp={id:op.id,clock:op.clock};clock=Math.max(clock,op.clock);
    for(const change of op.meta){
      if(!change||typeof change.id!=='string'||!change.patch||typeof change.patch!=='object')throw new Error('저장 기록의 문서 정보가 손상되었습니다.');
      const m=metas.get(change.id)||{id:change.id,title:'제목 없음',icon:'📄',parentId:null,children:[]};
      for(const [name,value]of Object.entries(change.patch)){
        if(!['title','icon','parentId','children','deleted','trashGroup','deletedAt','createdAt','updatedAt'].includes(name))continue;
        const k=key(change.id,name),old=fields.get(k);if(!old||stampCompare(old,stamp)<0){m[name]=Safe.clone(value);fields.set(k,stamp);}
      }metas.set(m.id,normalizeMeta(m));
    }
    if(op.rootOrder){const old=fields.get('$roots');if(!old||stampCompare(old,stamp)<0){ws.rootPageOrder=Array.from(new Set(op.rootOrder));fields.set('$roots',stamp);}}
    for(const entry of op.pages){
      const data=Safe.page(entry.data),id=data.id,history=versions.get(id)||[];
      history.push({opId:op.id,id:op.id,clock:op.clock,createdAt:op.createdAt,title:data.title,bases:entry.bases||[],device:op.device,session:op.session});history.sort(stampCompare);versions.set(id,history);
      // Recompute heads from the DAG, including out-of-order arrival.
      const referenced=new Set(history.flatMap(v=>v.bases));heads.set(id,new Set(history.filter(v=>!referenced.has(v.opId)).map(v=>v.opId)));
      if(latest(id)?.opId===op.id)remember(id,{...data,_revision:op.id});
    }
    if(op.favorite){const old=fields.get('$favorite:'+op.favorite.id);if(!old||stampCompare(old,stamp)<0){const set=new Set(settings.favorites);op.favorite.value?set.add(op.favorite.id):set.delete(op.favorite.id);settings.favorites=Array.from(set);fields.set('$favorite:'+op.favorite.id,stamp);}}
    if(op.settings)for(const [name,value]of Object.entries(op.settings)){if(!['favorites','expandedPages'].includes(name))continue;const old=fields.get('$settings:'+name);if(!old||stampCompare(old,stamp)<0){settings[name]=Safe.clone(value);fields.set('$settings:'+name,stamp);}}
    if(op.archives)op.archives.forEach((a,i)=>{const data=Safe.page(a.data),list=archives.get(data.id)||[];list.push({opId:op.id+'~'+i,createdAt:a.createdAt,title:data.title,archive:true,head:false});archives.set(data.id,list);});
    seen.add(op.id);if(op.meta.length||op.rootOrder)rebuild();
  }
  async function cacheOperation(op){
    const g=generation,capturedScope=scope;await LocalDB.put(capturedScope,'op-cache',op.id,op);guard(g);
    await LocalDB.putMany(capturedScope,'version-page',op.pages.map(e=>[op.id+':'+e.data.id,e.data]));guard(g);
    await LocalDB.putMany(capturedScope,'search',op.pages.map(e=>[e.data.id,{id:e.data.id,revision:op.id,text:Exporter.plainText(e.data.editorData).toLocaleLowerCase()}]));guard(g);
  }
  async function refreshInternal(g){
    if(!UI.isOnline()&&!Storage.isDemo()){online=false;throw new Error('인터넷 연결 후 동기화해 주세요. 기기 초안은 유지됩니다.');}
    const list=await Storage.listOperations();guard(g);
    const missing=list.filter(r=>!seen.has(r.opId)),operations=[];
    for(let i=0;i<missing.length;i+=4){const batch=await Promise.all(missing.slice(i,i+4).map(async ref=>{const cached=await LocalDB.get(scope,'op-cache',ref.opId),op=cached||await Storage.readOperation(ref);if(!op||op.id!==ref.opId)throw new Error('저장 기록 ID가 일치하지 않습니다.');await cacheOperation(op);refs.set(op.id,ref);return op;}));guard(g);operations.push(...batch);}
    operations.sort(stampCompare);for(const op of operations)apply(op);online=true;
    if(operations.length){await checkpoint();Safe.event('workspaceChanged',{remote:true});}
    return operations.length;
  }
  const refresh=()=>enqueue(refreshInternal);
  async function operation(id){const g=generation,capturedScope=scope;const cached=await LocalDB.get(capturedScope,'op-cache',id);guard(g);if(cached)return cached;const ref=refs.get(id);if(!ref)throw new Error('버전 기록을 찾을 수 없습니다.');const op=await Storage.readOperation(ref);guard(g);await LocalDB.put(capturedScope,'op-cache',id,op);return op;}
  async function loadPage(id,options={}){
    const g=generation;
    if(!metas.has(id)||(!options.includeTrash&&!active(id)))throw new Error('문서가 없거나 휴지통에 있습니다.');
    const revision=latest(id)?.opId||null;
    if(pages.has(id)&&pages.get(id)._revision===revision){const cached={...pages.get(id),title:metas.get(id).title,icon:metas.get(id).icon,parentId:metas.get(id).parentId};remember(id,cached);return Safe.clone(cached);}
    let data;
    if(revision){data=await LocalDB.get(scope,'version-page',revision+':'+id);guard(g);if(!data){const op=await operation(revision);data=op.pages.find(p=>p.data.id===id)?.data;if(data)await LocalDB.put(scope,'version-page',revision+':'+id,data);}}
    else data=await Storage.readPage(id);
    guard(g);if(!data)throw new Error('문서 파일이 누락되었습니다: '+metas.get(id).title);
    data={...Safe.page(data),title:metas.get(id).title,icon:metas.get(id).icon,parentId:metas.get(id).parentId,_revision:revision};remember(id,data);await LocalDB.put(scope,'page-cache',id,data);return Safe.clone(data);
  }
  async function offlinePage(id){if(!active(id))throw new Error('문서가 없거나 휴지통에 있습니다.');try{return await loadPage(id);}catch(e){if(e.status===404||/누락|손상|지원하지/.test(e.message))throw e;const cached=await LocalDB.get(scope,'page-cache',id);if(cached)return cached;throw e;}}
  async function persistDraft(id,snapshot,revision=state(id).edit,force=false){
    if(!id||!snapshot?.editorData)return false;const g=generation,capturedScope=scope,draftKey=id+'@'+sessionId;
    const record={id,draftKey,owner:sessionId,page:Safe.page(snapshot),revision,baseRevision:snapshot._revision??latest(id)?.opId??null,updatedAt:new Date().toISOString()};
    return draftRun(async()=>{guard(g);const old=await LocalDB.get(capturedScope,'draft',draftKey);guard(g);if(old&&old.revision>revision)return false;if(revision<state(id).ack||(!force&&revision===state(id).ack&&!isDirty(id)))return false;await LocalDB.put(capturedScope,'draft',draftKey,record);guard(g);if(revision<state(id).ack){await LocalDB.remove(capturedScope,'draft',draftKey);return false;}if(state(id).edit===revision&&isDirty(id)){state(id).status='local';emitState(id);}return true;});
  }
  const drafts=()=>LocalDB.list(scope,'draft');
  const getDraft=async(id,draftKey)=>{if(draftKey)return LocalDB.get(scope,'draft',draftKey);return await LocalDB.get(scope,'draft',id+'@'+sessionId)||(await drafts()).filter(d=>d.id===id).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt))[0]||null;};
  const discardDraft=async(id,draftKey)=>{const d=await getDraft(id,draftKey);if(d)await LocalDB.remove(scope,'draft',d.draftKey||id);};
  function emitState(id){const s=state(id);Safe.event('saveState',{pageId:id,...s,dirty:s.edit>s.ack});if(id===current)document.getElementById('unsaved-indicator')?.classList.toggle('hidden',s.edit<=s.ack);}
  function markDirty(id=current){if(!id)return 0;state(id).edit++;state(id).status='dirty';emitState(id);return state(id).edit;}
  function markClean(id=current,revision){if(!id)return;const s=state(id);s.ack=revision??s.edit;s.status=s.edit>s.ack?'dirty':'saved';emitState(id);}
  const isDirty=(id=current)=>!!id&&state(id).edit>state(id).ack;
  function basesFor(data,resolve=false){return resolve?currentHeads(data.id):(data._revision?[data._revision]:[]);}
  function checkBase(data,resolve=false){
    const actual=currentHeads(data.id);if(resolve)return;const expected=basesFor(data);
    if(JSON.stringify(actual)===JSON.stringify(expected))return;
    // Only this editor session may fast-forward its own acknowledged snapshots.
    const history=new Map((versions.get(data.id)||[]).map(v=>[v.opId,v])),target=data._revision||null,visited=new Set();
    const ownPath=id=>{if(id===target)return true;if(!id||visited.has(id))return false;visited.add(id);const v=history.get(id);if(!v||v.session!==sessionId)return false;return v.bases.length?v.bases.every(ownPath):target===null;};
    if(actual.length===1&&ownPath(actual[0])){data._revision=actual[0];return;}
    throw Object.assign(new Error('다른 기기 또는 탭의 변경이 있습니다. 초안을 보관했습니다. 버전 기록에서 비교하세요.'),{code:'CONFLICT',pageId:data.id});
  }

  async function commit(kind,changes,g){
    guard(g);const originalVersions=[];for(const entry of changes.pages||[])if(metas.has(entry.data.id)&&!latest(entry.data.id)&&!archives.has(entry.data.id)){const data=await loadPage(entry.data.id,{includeTrash:true});delete data._revision;originalVersions.push({data,createdAt:data.updatedAt||data.createdAt||new Date().toISOString()});}
    if(originalVersions.length)changes.archives=[...(changes.archives||[]),...originalVersions];
    guard(g);const op={schemaVersion:4,id:Safe.id(),device,session:sessionId,clock:Math.max(Date.now(),clock+1),createdAt:new Date().toISOString(),kind,meta:changes.meta||[],pages:(changes.pages||[]).map(e=>{const data=Safe.page(e.data);delete data._revision;return {...e,data};}),...(changes.rootOrder?{rootOrder:changes.rootOrder}:{}),...(changes.settings?{settings:changes.settings}:{}),...(changes.favorite?{favorite:changes.favorite}:{}),...(changes.archives?{archives:changes.archives}:{})};
    clock=op.clock;await LocalDB.put(scope,'pending',op.id,op);guard(g);
    const result=await Storage.appendOperation(op);guard(g);
    // Remote durable commit succeeded. Local cache/mirror errors must not erase that fact.
    refs.set(op.id,{opId:op.id,fileId:result.id});apply(op);
    try{await cacheOperation(op);await LocalDB.remove(scope,'pending',op.id);await checkpoint();}catch(e){Safe.event('syncStatus',{state:'warning',message:'원격 저장 완료 · 기기 캐시 갱신 실패'});}
    channel?.postMessage({id:op.id});Safe.event('workspaceChanged',{remote:false});scheduleMirror(op,g);return op;
  }
  function scheduleMirror(op,g){
    const capturedScope=scope;
    mirrorRun(async()=>{
      if(g!==generation)return;
      await LocalDB.put(capturedScope,'mirror',op.id,op);
      try{
        for(const entry of op.pages){guard(g);if(active(entry.data.id))await Storage.writePage(entry.data.id,entry.data);}
        for(const entry of op.meta){guard(g);if(entry.patch.deleted===true)await Storage.deletePage(entry.id);}
        if(op.meta.length||op.rootOrder){guard(g);await Storage.writeWorkspace({...Safe.clone(ws),schemaVersion:4,storage:'v9-operation-log'});}
        if(op.settings||op.favorite){guard(g);await Storage.writeSettings(settings);}
        await LocalDB.remove(capturedScope,'mirror',op.id);
      }catch(e){if(g===generation)Safe.event('syncStatus',{state:'warning',message:'저장 기록은 보관됨 · 호환 파일 갱신 대기'});}
    }).catch(Safe.report);
  }
  async function savePage(id,editorData,title,icon,coverImageId=null,options={}){
    const revision=options.revision??state(id).edit;
    const currentData=options.snapshot||await offlinePage(id);
    const data={...currentData,id,title,icon,coverImageId,editorData:Safe.editor(editorData),updatedAt:new Date().toISOString()};
    await persistDraft(id,data,revision,true);
    return enqueue(async g=>{
      try{
        state(id).status='saving';emitState(id);await refreshInternal(g);guard(g);
        if(!active(id))throw new Error('삭제된 문서입니다. 초안에서 내용을 복구해 주세요.');
        const existing=await loadPage(id);const clean=Safe.page(data);delete clean._revision;
        if(currentHeads(id).length<=1&&JSON.stringify(existing.editorData)===JSON.stringify(clean.editorData)&&existing.title===clean.title&&existing.icon===clean.icon&&existing.coverImageId===clean.coverImageId){markClean(id,revision);const draft=await getDraft(id);if(draft&&draft.owner===sessionId&&draft.revision<=revision)await LocalDB.remove(scope,'draft',draft.draftKey||id);return true;}
        checkBase(data,options.resolveConflict);
        const patch={};for(const field of ['title','icon'])if(active(id)[field]!==clean[field])patch[field]=clean[field];
        const order=bodyOrder(id,clean.editorData);if(JSON.stringify(order)!==JSON.stringify(active(id).children))patch.children=order;
        const op=await commit('page.save',{pages:[{data:clean,bases:basesFor(data,options.resolveConflict)}],meta:Object.keys(patch).length?[{id,patch}]:[]},g);
        if(pages.has(id))pages.get(id)._revision=op.id;
        markClean(id,revision);const draft=await getDraft(id);if(draft&&draft.owner===sessionId&&draft.revision<=revision)await LocalDB.remove(scope,'draft',draft.draftKey||id);return true;
      }catch(e){state(id).status=e.code==='CONFLICT'?'conflict':'error';emitState(id);throw e;}
    });
  }
  function getPageMeta(id){return active(id);}
  function getAllPagesMeta(){return Array.from(metas.values()).filter(m=>!m.deleted);}
  const getChildren=id=>(children.get(id)||[]).slice(),getRootPages=()=>getChildren(null);
  function getAncestors(id){const list=[],visited=new Set([id]);let m=active(id);while(m?.parentId){if(visited.has(m.parentId))throw new Error('문서 계층에 순환이 있습니다. 진단에서 복구하세요.');visited.add(m.parentId);m=active(m.parentId);if(!m)break;list.unshift(m);if(list.length>1000)throw new Error('계층이 너무 깊습니다.');}return list;}
  const getDepth=id=>getAncestors(id).length;
  function bodyOrder(id,data){const allowed=new Set(getChildren(id).map(m=>m.id));const order=[];Safe.walkBlocks(data.blocks||[],b=>{if(b.type==='pageLink'&&allowed.has(b.data.pageId)&&!order.includes(b.data.pageId))order.push(b.data.pageId);});return order.concat(getChildren(id).map(m=>m.id).filter(id=>!order.includes(id)));}
  async function createPage(parentId=null,options={}){return enqueue(async g=>{
    await refreshInternal(g);if(parentId&&!active(parentId))throw new Error('부모 문서를 찾을 수 없습니다.');if(parentId&&getDepth(parentId)>=4)throw new Error('최대 5단계까지만 중첩할 수 있습니다.');
    const id=Safe.id(),now=new Date().toISOString();const meta={id,title:options.title||'제목 없음',icon:options.icon||'📄',parentId,children:[],createdAt:now,deleted:false};
    const page=Safe.page({id,title:meta.title,icon:meta.icon,parentId,coverImageId:parentId?null:options.coverImageId||null,createdAt:now,updatedAt:now,editorData:options.editorData||{blocks:[]}});
    const changes={meta:[{id,patch:meta}],pages:[{data:page,bases:[]}]};
    if(parentId){const parent=await loadPage(parentId);checkBase(parent);let placeholder;Safe.walkBlocks(parent.editorData.blocks,b=>{if(b.id===options.linkBlockId&&b.type==='pageLink'&&!b.data.pageId)placeholder=b;});if(placeholder)placeholder.data.pageId=id;else parent.editorData.blocks.push({id:Safe.id(),type:'pageLink',data:{pageId:id}});changes.pages.push({data:Safe.page(parent),bases:basesFor(parent)});changes.meta.push({id:parentId,patch:{children:getChildren(parentId).map(m=>m.id).concat(id)}});}
    else changes.rootOrder=getRootPages().map(m=>m.id).concat(id);
    await commit('page.create',changes,g);return {meta:active(id),pageData:await loadPage(id)};
  });}
  async function renamePage(id,title){return enqueue(async g=>{await refreshInternal(g);const page=await loadPage(id);checkBase(page);page.title=Safe.text(title).trim()||'제목 없음';page.updatedAt=new Date().toISOString();await commit('page.rename',{meta:[{id,patch:{title:page.title}}],pages:[{data:Safe.page(page),bases:basesFor(page)}]},g);return true;});}
  async function duplicatePage(id){return enqueue(async g=>{
    await refreshInternal(g);const source=active(id);if(!source)throw new Error('복제할 문서를 찾을 수 없습니다.');
    const ids=[],visited=new Set();function scan(pid){if(visited.has(pid))throw new Error('계층 순환을 먼저 복구하세요.');visited.add(pid);ids.push(pid);for(const child of getChildren(pid))scan(child.id);}scan(id);
    const copies=new Map();for(let i=0;i<ids.length;i+=4){for(const p of await Promise.all(ids.slice(i,i+4).map(pid=>loadPage(pid)))){checkBase(p);copies.set(p.id,p);}guard(g);}
    const pageMap=new Map(ids.map(pid=>[pid,Safe.id()])),now=new Date().toISOString(),changes={meta:[],pages:[]};
    for(const pid of ids){const old=copies.get(pid),meta=active(pid),newId=pageMap.get(pid),parentId=pid===id?source.parentId:pageMap.get(meta.parentId),title=old.title+(pid===id?' (복사)':'');
      const data=Safe.page({...old,id:newId,parentId,title,createdAt:now,updatedAt:now,editorData:{...old.editorData,blocks:Safe.copyBlocks(old.editorData.blocks,pageMap)}});delete data._revision;
      changes.pages.push({data,bases:[]});changes.meta.push({id:newId,patch:{id:newId,title,icon:old.icon,parentId,children:getChildren(pid).map(c=>pageMap.get(c.id)),createdAt:now,updatedAt:now,deleted:false}});
    }
    const cloneId=pageMap.get(id),siblings=getChildren(source.parentId).map(m=>m.id);siblings.splice(siblings.indexOf(id)+1,0,cloneId);
    if(source.parentId){const parent=await loadPage(source.parentId);checkBase(parent);let anchor=null,list=null;Safe.walkBlocks(parent.editorData.blocks,(b,owner)=>{if(!anchor&&b.type==='pageLink'&&b.data.pageId===id){anchor=b;list=owner;}});const link={id:Safe.id(),type:'pageLink',data:{pageId:cloneId}};if(anchor)list.splice(list.indexOf(anchor)+1,0,link);else parent.editorData.blocks.push(link);changes.pages.push({data:Safe.page(parent),bases:basesFor(parent)});changes.meta.push({id:source.parentId,patch:{children:siblings}});}
    else changes.rootOrder=siblings;
    await commit('page.duplicateTree',changes,g);return {meta:active(cloneId),pageData:await loadPage(cloneId),count:ids.length};
  });}
  async function moveBlocks(sourceId,blockIds,targetId,targetToggleId=null){return enqueue(async g=>{
    await refreshInternal(g);
    if(!Array.isArray(blockIds)||!blockIds.length||new Set(blockIds).size!==blockIds.length)throw new Error('이동할 블록을 선택하세요.');
    const source=await loadPage(sourceId),target=sourceId===targetId?source:await loadPage(targetId);checkBase(source);if(target!==source)checkBase(target);
    const selected=new Set(blockIds),found=new Map(),destination=[];
    Safe.walkBlocks(source.editorData.blocks,(b,list)=>{if(selected.has(b.id))found.set(b.id,{b,list});});
    if(found.size!==selected.size)throw new Error('본문이 변경되었습니다. 이동할 블록을 다시 선택하세요.');
    // Selecting a container already includes its descendants, in document order.
    for(const {b}of found.values())if(b.type==='toggle'&&b.data.children)Safe.walkBlocks(b.data.children,child=>selected.delete(child.id));
    let targetBlock=null;if(targetToggleId)Safe.walkBlocks(target.editorData.blocks,b=>{if(b.id===targetToggleId&&b.type==='toggle')targetBlock=b;});
    if(targetToggleId&&!targetBlock)throw new Error('이동할 토글이 없거나 변경되었습니다.');
    for(const {b}of found.values())if(selected.has(b.id)){if(source===target){let cycle=b===targetBlock;if(b.type==='toggle'&&b.data.children)Safe.walkBlocks(b.data.children,child=>{if(child===targetBlock)cycle=true;});if(cycle)throw new Error('블록을 자기 자신이나 그 안의 토글로 옮길 수 없습니다.');}destination.push(b);}
    for(const {b,list}of found.values())if(selected.has(b.id))list.splice(list.indexOf(b),1);
    const out=targetBlock?(targetBlock.data.children||= []):target.editorData.blocks;
    // A cross-page move receives fresh block IDs; linked pages and files keep their references.
    out.push(...(source===target?destination:Safe.copyBlocks(destination)));if(targetBlock)targetBlock.data.isOpen=true;
    const changed=source===target?[source]:[source,target],now=new Date().toISOString();
    const changes={pages:[],meta:[]};for(const p of changed){p.updatedAt=now;changes.pages.push({data:Safe.page(p),bases:basesFor(p)});const order=bodyOrder(p.id,p.editorData);if(JSON.stringify(order)!==JSON.stringify(active(p.id).children))changes.meta.push({id:p.id,patch:{children:order}});}
    await commit('blocks.move',changes,g);return destination.length;
  });}
  async function deletePage(id){return enqueue(async g=>{
    await refreshInternal(g);if(!active(id))return false;
    const ids=[],scan=(p,seenIds=new Set())=>{if(seenIds.has(p))throw new Error('계층 순환을 먼저 복구하세요.');seenIds.add(p);ids.push(p);for(const c of getChildren(p))scan(c.id,seenIds);};scan(id);
    const group=Safe.id(),now=new Date().toISOString(),changes={meta:[],pages:[],settings:{favorites:settings.favorites.filter(x=>!ids.includes(x))}};
    for(const pid of ids){const p=await loadPage(pid);checkBase(p);changes.pages.push({data:Safe.page(p),bases:basesFor(p)});changes.meta.push({id:pid,patch:{deleted:true,trashGroup:group,deletedAt:now}});}
    await commit('page.delete',changes,g);if(ids.includes(current))Safe.event('activePageDeleted',{ids});return true;
  });}
  const getTrash=()=>Array.from(metas.values()).filter(m=>m.deleted);
  async function restoreTrash(id){return enqueue(async g=>{
    await refreshInternal(g);const selected=metas.get(id);if(!selected?.deleted)return false;const group=getTrash().filter(m=>m.trashGroup===selected.trashGroup),groupIds=new Set(group.map(m=>m.id));
    const changes={meta:[],pages:[]};for(const m of group){const p=await loadPage(m.id,{includeTrash:true}),parentId=active(m.parentId)||groupIds.has(m.parentId)?m.parentId:null;p.parentId=parentId;changes.meta.push({id:m.id,patch:{deleted:false,parentId}});changes.pages.push({data:Safe.page(p),bases:currentHeads(m.id)});}
    await commit('page.restore',changes,g);return true;
  });}
  async function reorderRootPage(id,before){return enqueue(async g=>{await refreshInternal(g);if(!active(id)||active(id).parentId||id===before)return false;const order=getRootPages().map(m=>m.id).filter(x=>x!==id),at=before==null?order.length:order.indexOf(before);if(at<0)throw new Error('이동 위치를 찾을 수 없습니다.');order.splice(at,0,id);await commit('page.order',{rootOrder:order},g);return true;});}
  async function moveRootPage(id,direction){const order=getRootPages().map(m=>m.id),i=order.indexOf(id),target=i+(direction<0?-1:1);if(i<0||target<0||target>=order.length)return false;return reorderRootPage(id,direction<0?order[target]:order[target+1]||null);}
  async function reorderChildrenStored(parentId,order){return enqueue(async g=>{await refreshInternal(g);const actual=getChildren(parentId).map(m=>m.id);if(order.length!==actual.length||new Set(order).size!==order.length||order.some(id=>!actual.includes(id)))throw new Error('자식 문서 목록이 바뀌었습니다. 다시 시도하세요.');const p=await loadPage(parentId);checkBase(p);const links=[];Safe.walkBlocks(p.editorData.blocks,b=>{if(b.type==='pageLink'&&actual.includes(b.data.pageId))links.push(b);});const linked=new Set(links.map(b=>b.data.pageId)),sorted=order.filter(id=>linked.has(id)),placed=new Set();let i=0;for(const b of links){const old=b.data.pageId;if(!placed.has(old)){placed.add(old);b.data.pageId=sorted[i++];}}await commit('page.order',{meta:[{id:parentId,patch:{children:order}}],pages:[{data:Safe.page(p),bases:basesFor(p)}]},g);return true;});}
  function syncChildrenOrderLive(){return false;} // Changes commit with the captured body, never by mutating a shared tree.
  async function appendChildLink(parentId,childId){const p=await loadPage(parentId);let exists=false;Safe.walkBlocks(p.editorData.blocks,b=>{if(b.type==='pageLink'&&b.data.pageId===childId)exists=true;});if(exists)return true;p.editorData.blocks.push({id:Safe.id(),type:'pageLink',data:{pageId:childId}});return savePage(parentId,p.editorData,p.title,p.icon,p.coverImageId,{snapshot:p});}
  async function removeChildLink(parentId,childId){const p=await loadPage(parentId);const matches=[];Safe.walkBlocks(p.editorData.blocks,(b,list)=>{if(b.type==='pageLink'&&b.data.pageId===childId)matches.push([b,list]);});for(const [b,list]of matches)list.splice(list.indexOf(b),1);return savePage(parentId,p.editorData,p.title,p.icon,p.coverImageId,{snapshot:p});}
  async function toggleFavorite(id){return enqueue(async g=>{await refreshInternal(g);if(!active(id))return false;const values=new Set(settings.favorites);values.has(id)?values.delete(id):values.add(id);await commit('settings.favorite',{favorite:{id,value:values.has(id)}},g);return values.has(id);});}
  function setExpandedPages(ids){const value=Array.from(new Set(ids)).filter(id=>active(id));settings.expandedPages=value;localStorage.setItem('darakbang_expanded:'+scope,JSON.stringify(value));return Promise.resolve();}
  function loadExpandedFromLocal(){try{return JSON.parse(localStorage.getItem('darakbang_expanded:'+scope)||'null')||settings.expandedPages||[];}catch{return settings.expandedPages||[];}}
  function textOf(data){return Exporter.plainText(data);}
  async function searchPages(query,options={}){const q=Safe.text(query).trim().toLocaleLowerCase();if(!q)return [];const result=[],g=generation,list=getAllPagesMeta(),indexById=new Map((await LocalDB.list(scope,'search')).map(x=>[x.id,x]));let done=0,lastYield=performance.now();
    for(const m of list){guard(g);if(options.cancelled?.())return [];const rev=latest(m.id)?.opId||'legacy';let index=indexById.get(m.id);if(!index||index.revision!==rev){try{const p=await offlinePage(m.id);index={id:m.id,revision:rev,text:textOf(p.editorData).toLocaleLowerCase()};await LocalDB.put(scope,'search',m.id,index);}catch{index={text:''};}}
      if(m.title.toLocaleLowerCase().includes(q)||index.text.includes(q))result.push(m);if(++done%200===0&&performance.now()-lastYield>8){Safe.event('searchProgress',{done,total:list.length});await new Promise(r=>setTimeout(r,0));lastYield=performance.now();}}
    return result;
  }
  async function getVersions(id){return (versions.get(id)||[]).slice().reverse().map(v=>({...v,head:heads.get(id)?.has(v.opId)})).concat((archives.get(id)||[]).slice().reverse());}
  async function versionPage(id,opId){if(opId.includes('~')){const [parent,i]=opId.split('~');const a=(await operation(parent)).archives?.[Number(i)];if(a?.data?.id!==id)throw new Error('이전 백업 버전을 찾을 수 없습니다.');return Safe.clone(a.data);}const op=await operation(opId);const entry=op.pages.find(e=>e.data.id===id);if(!entry)throw new Error('버전을 찾을 수 없습니다.');return Safe.clone(entry.data);}
  async function restoreVersion(id,opId){const p=await versionPage(id,opId);p._revision=latest(id)?.opId;markDirty(id);return savePage(id,p.editorData,p.title,p.icon,p.coverImageId,{snapshot:p,resolveConflict:true});}
  async function retryPending(){return enqueue(async g=>{
    await refreshInternal(g);const pending=(await LocalDB.list(scope,'pending')).sort(stampCompare),changed=new Set();
    for(const op of pending){guard(g);if(!seen.has(op.id)){const r=await Storage.appendOperation(op);refs.set(op.id,{opId:op.id,fileId:r.id});await cacheOperation(op);apply(op);}for(const e of op.pages)changed.add(e.data.id);await LocalDB.remove(scope,'pending',op.id);scheduleMirror(op,g);}
    const reconcile=[];for(const id of changed){const currentVersions=(versions.get(id)||[]).filter(v=>heads.get(id)?.has(v.opId)),owners=new Set(currentVersions.map(v=>v.session));if(active(id)&&currentVersions.length>1&&owners.size===1&&currentVersions[0].session){const data=await loadPage(id);reconcile.push({data,bases:currentHeads(id)});}}
    if(reconcile.length)await commit('sync.reconcile',{pages:reconcile},g);
    for(const id of changed){const d=await getDraft(id);if(d?.owner===sessionId&&active(id)&&currentHeads(id).length===1){const saved=await loadPage(id),same=p=>JSON.stringify([p.title,p.icon,p.coverImageId,p.editorData]);if(same(saved)===same(d.page)&&state(id).edit<=d.revision){markClean(id,d.revision);await LocalDB.remove(scope,'draft',d.draftKey);}}}
    for(const op of await LocalDB.list(scope,'mirror'))scheduleMirror(op,g);await checkpoint();Safe.event('workspaceChanged',{remote:true});return pending.length;
  });}
  async function diagnostics(){const issues=[],all=getAllPagesMeta();for(const m of all){if(m.parentId&&!active(m.parentId))issues.push({kind:'orphan',id:m.id,message:m.title+'의 부모가 없습니다.'});try{if(getDepth(m.id)>4)issues.push({kind:'depth',id:m.id,message:m.title+'의 중첩 깊이 초과'});}catch{issues.push({kind:'cycle',id:m.id,message:m.title+'의 계층 순환'});}if((heads.get(m.id)?.size||0)>1)issues.push({kind:'conflict',id:m.id,message:m.title+'에 동시 수정 버전이 있습니다.'});}
    return {issues,pending:await LocalDB.list(scope,'pending'),mirrors:await LocalDB.list(scope,'mirror'),drafts:await drafts(),pageCount:all.length,trashCount:getTrash().length};}
  async function repairHierarchy(){return enqueue(async g=>{await refreshInternal(g);const changes=[];for(const m of getAllPagesMeta()){let broken=!!m.parentId&&!active(m.parentId);try{broken=broken||getDepth(m.id)>4;}catch{broken=true;}if(broken)changes.push({id:m.id,patch:{parentId:null}});}if(changes.length)await commit('repair.hierarchy',{meta:changes},g);return changes.length;});}
  async function snapshotState(){const out=[],ids=Array.from(metas.keys());for(let i=0;i<ids.length;i+=4)out.push(...await Promise.all(ids.slice(i,i+4).map(id=>loadPage(id,{includeTrash:true}))));return {workspace:Safe.clone(ws),settings:Safe.clone(settings),pages:out};}
  async function snapshotHistory(){const out=[];for(const id of seen)out.push(await operation(id));return out;}
  return {init,reset,refresh,retryPending,diagnostics,repairHierarchy,persistDraft,getDraft,drafts,discardDraft,getVersions,versionPage,restoreVersion,getTrash,restoreTrash,
    getPageMeta,getAllPagesMeta,getRootPages,getChildren,getDepth,getAncestors,createPage,loadPage:offlinePage,savePage,deletePage,renamePage,duplicatePage,moveBlocks,appendChildLink,removeChildLink,moveRootPage,reorderRootPage,reorderChildrenStored,syncChildrenOrderLive,
    getChildrenIds:id=>getChildren(id).map(m=>m.id),getRootIndex:id=>getRootPages().findIndex(m=>m.id===id),getRootCount:()=>getRootPages().length,
    isFavorite:id=>settings?.favorites.includes(id),getFavorites:()=>settings.favorites.map(active).filter(Boolean),toggleFavorite,getExpandedPages:()=>settings.expandedPages,setExpandedPages,loadExpandedFromLocal,
    markDirty,markClean,isDirty,getCurrentPageId:()=>current,setCurrentPageId:id=>{current=id;if(id)emitState(id);},getEditRevision:id=>state(id||current).edit,getState:id=>({...state(id||current)}),searchPages,
    get scope(){return scope;},get workspace(){return ws;},get settings(){return settings;},get online(){return online;},
    exportState:()=>enqueue(snapshotState),allHistory:()=>enqueue(snapshotHistory),exportArchive:()=>enqueue(async()=>({state:await snapshotState(),history:await snapshotHistory()})),
    resolveDraft:async(id,draftKey)=>{const d=await getDraft(id,draftKey);if(!d)throw new Error('초안이 없습니다.');const p=d.page;markDirty(id);const result=await savePage(id,p.editorData,p.title,p.icon,p.coverImageId,{snapshot:p,resolveConflict:true});await LocalDB.remove(scope,'draft',d.draftKey||id);return result;},
    importPages:(imported,meta,importSettings,archives)=>enqueue(async g=>{await refreshInternal(g);return commit('backup.restore',{pages:imported.map(data=>({data:Safe.page(data),bases:[]})),meta:meta.map(m=>({id:m.id,patch:m})),settings:importSettings,archives},g);})
  };
})();

