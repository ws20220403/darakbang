/* Shared validation. Stored strings are data; only a small inline HTML vocabulary is rendered. */
const Safe = (() => {
  const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
  const id = () => crypto.randomUUID();
  const event = (name, detail = {}) => document.dispatchEvent(new CustomEvent('darakbang:' + name, { detail }));
  const text = value => String(value == null ? '' : value);
  const escape = value => text(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function url(value, link = true) {
    try { const u = new URL(text(value)); return (link ? ['https:', 'http:', 'mailto:', 'tel:'] : ['https:', 'http:']).includes(u.protocol) ? u.href : ''; }
    catch { return ''; }
  }
  const richRules = { b:true,strong:true,i:true,em:true,u:true,s:true,a:{href:true,target:true,rel:true},code:true,mark:true,br:true,p:true,div:true,ul:true,ol:{start:true},li:{value:true},blockquote:true,pre:true,h1:true,h2:true,h3:true,h4:true,h5:true,h6:true,table:true,thead:true,tbody:true,tfoot:true,tr:true,td:{colspan:true,rowspan:true},th:{colspan:true,rowspan:true} };
  function html(value, rich = false) {
    const doc = new DOMParser().parseFromString(text(value), 'text/html');
    const out = document.createElement('div');
    const tags = new Set(rich ? Object.keys(richRules).map(t=>t.toUpperCase()) : ['B','STRONG','I','EM','U','A','CODE','MARK','BR','S']);
    function copy(source, dest) {
      for (const node of source.childNodes) {
        if (node.nodeType === 3) { dest.appendChild(document.createTextNode(node.textContent)); continue; }
        if (node.nodeType !== 1 || ['SCRIPT','STYLE','IFRAME','OBJECT','TEMPLATE','SVG','MATH','BUTTON','SELECT','TEXTAREA'].includes(node.tagName)) continue;
        if(rich && node.tagName==='INPUT') { if(node.getAttribute('type')==='checkbox')dest.appendChild(document.createTextNode(node.hasAttribute('checked')?'☑ ':'☐ ')); continue; }
        if((rich && node.tagName==='SPAN')||node.tagName==='STRIKE'||node.tagName==='DEL') {
          let parent=dest;
          const styles=node.style, decorators=[];
          if(node.tagName==='STRIKE'||node.tagName==='DEL'||styles.textDecorationLine.includes('line-through'))decorators.push('s');
          if(styles.fontWeight==='bold'||Number(styles.fontWeight)>=600)decorators.push('b');
          if(styles.fontStyle==='italic')decorators.push('i');
          if(styles.textDecorationLine.includes('underline'))decorators.push('u');
          for(const tag of decorators){const el=document.createElement(tag);parent.appendChild(el);parent=el;}
          copy(node,parent);continue;
        }
        if (!tags.has(node.tagName)) {const line=['DIV','P','LI','H1','H2','H3'].includes(node.tagName);if(line&&dest.childNodes.length&&dest.lastChild.nodeName!=='BR')dest.appendChild(document.createElement('br'));copy(node, dest);if(line&&node.nextSibling)dest.appendChild(document.createElement('br'));continue;}
        const el = document.createElement(node.tagName.toLowerCase());
        if(rich)for(const attr of ['start','value','colspan','rowspan']) {
          if(!richRules[node.tagName.toLowerCase()]?.[attr])continue;
          const raw=node.getAttribute(attr);if(raw!==null&&/^-?\d{1,5}$/.test(raw)){const n=Number(raw);if(['colspan','rowspan'].includes(attr)?n>=1&&n<=200:Math.abs(n)<=10000)el.setAttribute(attr,String(n));}
        }
        if (node.tagName === 'A') {
          const href = url(node.getAttribute('href'));
          if (href) { el.setAttribute('href', href); el.setAttribute('rel', 'noopener noreferrer'); el.setAttribute('target', '_blank'); }
        }
        copy(node, el);
        if(rich&&['UL','OL'].includes(el.tagName)&&['UL','OL'].includes(dest.tagName)&&dest.lastElementChild?.tagName==='LI')dest.lastElementChild.appendChild(el);
        else dest.appendChild(el);
      }
    }
    copy(doc.body, out); return out.innerHTML;
  }
  function plain(value) { const el = document.createElement('div'); el.innerHTML = html(value); return el.textContent || ''; }
  function editor(data) {
    if (!data || !Array.isArray(data.blocks)) throw new Error('본문 데이터 형식이 올바르지 않습니다. 원본은 보존됩니다.');
    if (data.blocks.length > 10000) throw new Error('한 문서는 최대 10,000개 블록을 지원합니다.');
    const result = clone(data), used = new Set();
    for (const b of result.blocks) {
      if (!b || typeof b.type !== 'string' || !b.data || typeof b.data !== 'object') throw new Error('손상된 블록 데이터입니다.');
      if (!b.id || used.has(b.id)) b.id = id(); used.add(b.id);
      const d = b.data;
      if (['paragraph','header','quote'].includes(b.type)) d.text = html(d.text);
      if (b.type === 'callout') d.text = html(d.text,true);
      if (b.type === 'quote') d.caption = html(d.caption);
      if (b.type === 'toggle') { d.title = html(d.title); d.content = html(d.content,true); }
      if (b.type === 'list') {
        const scan = (items, depth=0) => { if (!Array.isArray(items) || depth > 20) throw new Error('목록 중첩/형식이 올바르지 않습니다.'); return items.map(item => typeof item === 'string' ? html(item) : {...item, content:html(item.content), items:scan(item.items || [], depth+1)}); };
        d.items = scan(d.items || []);
      }
      if (b.type === 'checklist') d.items = (d.items || []).map(item=>({text:html(item.text),checked:!!item.checked}));
      if (b.type === 'bookmark') { d.url = url(d.url,false); d.title = text(d.title); }
      if (['image','attachment'].includes(b.type)) { d.caption=text(d.caption); if (d.fileId != null && !/^[\w.-]+$/.test(d.fileId)) throw new Error('파일 참조가 올바르지 않습니다.'); }
      if (['table','spreadsheet'].includes(b.type)) {
        const grid = d.content || d.cells;
        if (!Array.isArray(grid) || grid.length > 1000 || grid.some(r=>!Array.isArray(r)||r.length>200)) throw new Error('표는 최대 1,000행 × 200열을 지원합니다.');
      }
      if (!['left','center','right'].includes(d.alignment)) delete d.alignment;
    }
    delete result.time;
    return result;
  }
  function page(data) {
    if (!data || typeof data.id !== 'string' || !/^[\w.-]+$/.test(data.id)) throw new Error('문서 ID가 올바르지 않습니다.');
    return {...clone(data), title:text(data.title).slice(0,500), icon:text(data.icon).slice(0,40), editorData:editor(data.editorData)};
  }
  function timeout(promise, ms, label='작업') {
    let timer;
    return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label+' 시간이 초과되었습니다. 내용은 보존됩니다.')),ms);})]).finally(()=>clearTimeout(timer));
  }
  async function hash(value) {
    const bytes = value instanceof Blob ? await value.arrayBuffer() : new TextEncoder().encode(typeof value === 'string' ? value : JSON.stringify(value));
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)), b=>b.toString(16).padStart(2,'0')).join('');
  }
  function queue() { let tail=Promise.resolve(); return task=>{const next=tail.then(task);tail=next.catch(()=>{});return next;}; }
  function report(error) { console.warn(error?.code || error?.name || 'Operation failed'); if (typeof UI !== 'undefined') UI.toast(error?.message || '작업에 실패했습니다.','error',6000); }
  return {clone,id,event,text,escape,url,html,rich:value=>html(value,true),richRules,plain,editor,page,timeout,hash,queue,report};
})();
