/* OAuth requests are bounded and serialized; expired access requires an explicit reconnect click. */
const Auth=(()=>{
  const DEFAULT_CLIENT_ID='1055434776065-64gj8snigehdl2krfjprnr6p4lo7k91u.apps.googleusercontent.com';
  const K='darakbang_',scope='https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email';
  let client=null,initFlight=null,flight=null,settle=null,epoch=0,activeToken=null,activeUser=null;
  const getPersist=()=>localStorage.getItem(K+'persist')==='1';
  const store=()=>getPersist()?localStorage:sessionStorage;
  const getClientId=()=>(localStorage.getItem(K+'client_id')||DEFAULT_CLIENT_ID).trim();
  const isConfigured=()=>/^\d+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(getClientId());
  function clearTokens(){epoch++;settle?.(new Error('인증 요청이 취소되었습니다.'));settle=null;flight=null;for(const s of[localStorage,sessionStorage])if(!activeToken||s.getItem(K+'token')===activeToken.value)for(const k of['token','token_expires','user'])s.removeItem(K+k);activeToken=null;activeUser=null;}
  function init(){if(client)return Promise.resolve();if(initFlight)return initFlight;initFlight=(async()=>{
    for(let i=0;i<40&&!window.google?.accounts?.oauth2;i++)await new Promise(r=>setTimeout(r,150));
    if(!window.google?.accounts?.oauth2)throw new Error('Google 연결 모듈을 불러오지 못했습니다. 연결 후 다시 시도하세요.');
    client=true;
  })().finally(()=>{initFlight=null;});return initFlight;}
  async function login(){await init();if(flight)return flight;exitDemo();const g=++epoch;
    let finished=false;
    const pending=new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>finish(new Error('로그인 시간이 초과되었습니다. 다시 연결하세요.')),90000);
      function finish(e,v){if(finished)return;finished=true;clearTimeout(timer);if(g===epoch)settle=null;e?reject(e):resolve(v);}
      settle=e=>finish(e);
      const callback=r=>{if(finished||g!==epoch)return;if(r.error)return finish(new Error('Google 로그인 실패: '+r.error));if(!r.access_token||!Number.isFinite(Number(r.expires_in)))return finish(new Error('로그인 응답이 올바르지 않습니다.'));
        for(const s of[localStorage,sessionStorage])for(const k of['token','token_expires','user'])s.removeItem(K+k);
        activeToken={value:r.access_token,expires:Date.now()+Math.max(0,Number(r.expires_in)-60)*1000};activeUser=null;store().setItem(K+'token',activeToken.value);store().setItem(K+'token_expires',String(activeToken.expires));finish(null,r.access_token);
      };
      try{const requestClient=google.accounts.oauth2.initTokenClient({client_id:getClientId(),scope,callback,error_callback:e=>{if(g===epoch)finish(new Error('Google 로그인: '+(e.type||'실패')));}});requestClient.requestAccessToken({prompt:'select_account'});}catch(e){finish(e);}
    });
    flight=pending;pending.finally(()=>{if(flight===pending)flight=null;}).catch(()=>{});return pending;
  }
  async function getToken(){if(!activeToken)activeToken={value:store().getItem(K+'token'),expires:Number(store().getItem(K+'token_expires'))};if(activeToken.value&&Date.now()<activeToken.expires)return activeToken.value;Safe.event('authRequired');throw Object.assign(new Error('Google 연결이 만료되었습니다. 다시 연결하면 보관된 초안을 저장할 수 있습니다.'),{code:'AUTH_REQUIRED',status:401});}
  const isDemo=()=>sessionStorage.getItem(K+'demo')==='1';
  const enterDemo=()=>sessionStorage.setItem(K+'demo','1');
  function exitDemo(){sessionStorage.removeItem(K+'demo');localStorage.removeItem(K+'demo');}
  function logout(){const token=activeToken?.value||store().getItem(K+'token');clearTokens();exitDemo();if(token)window.google?.accounts?.oauth2?.revoke(token,()=>{});}
  const isLoggedIn=()=>isDemo()||!!(store().getItem(K+'token')&&Date.now()<Number(store().getItem(K+'token_expires')));
  async function fetchUserInfo(){if(isDemo())return{id:'demo',name:'데모 사용자',email:'데모 모드 · 로컬 저장',picture:''};if(activeUser)return activeUser;const cached=store().getItem(K+'user');if(cached&&(!activeToken||store().getItem(K+'token')===activeToken.value)){try{activeUser=JSON.parse(cached);await getToken();return activeUser;}catch{activeUser=null;}}
    const g=epoch,token=await getToken(),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
    try{const res=await fetch('https://www.googleapis.com/oauth2/v2/userinfo',{signal:controller.signal,headers:{Authorization:'Bearer '+token}});if(!res.ok)throw new Error('사용자 정보 조회 실패 ('+res.status+')');const u=await res.json();if(g!==epoch)throw new DOMException('계정 변경','AbortError');if(!u.id)throw new Error('계정 ID 누락');const user={id:u.id,name:u.name,email:u.email,picture:u.picture};activeUser=user;if(store().getItem(K+'token')===token)store().setItem(K+'user',JSON.stringify(user));return user;}finally{clearTimeout(timer);}
  }
  return{init,login,logout,getToken,isLoggedIn,fetchUserInfo,clearTokens,enterDemo,exitDemo,isDemo,getClientId,isConfigured,getPersist,setPersist:v=>localStorage.setItem(K+'persist',v?'1':'0'),setClientId:id=>{clearTokens();client=null;initFlight=null;if(id?.trim())localStorage.setItem(K+'client_id',id.trim());else localStorage.removeItem(K+'client_id');}};
})();
