/* Keep clipboard and text editing inside the focused editable, before Editor.js splits it. */
const InlineEditing = (() => {
  function selectionInside(el) {
    const selection=window.getSelection();
    if(!selection?.rangeCount)return null;
    const range=selection.getRangeAt(0);
    return el.contains(range.startContainer)&&el.contains(range.endContainer)?range:null;
  }
  function changed(el) {
    el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertFromPaste'}));
    Workspace.markDirty();Safe.event('editorChanged');
  }
  function insert(el, value, {plain=false}={}) {
    let range=selectionInside(el);
    if(!range)return false;
    el.dataset.pasteInProgress='true';
    try {
      // The browser command preserves native text undo and replaces only the current selection.
      const ok=document.execCommand(plain?'insertText':'insertHTML',false,value);
      if(!ok) {
        range=selectionInside(el);if(!range)return false;
        range.deleteContents();
        const fragment=document.createDocumentFragment();
        if(plain)fragment.appendChild(document.createTextNode(value));
        else {const container=document.createElement('div');container.innerHTML=value;fragment.append(...container.childNodes);}
        const last=fragment.lastChild;
        range.insertNode(fragment);
        if(last){range.setStartAfter(last);range.collapse(true);const s=window.getSelection();s.removeAllRanges();s.addRange(range);}
      }
      changed(el);return true;
    } finally {delete el.dataset.pasteInProgress;}
  }
  function textFromHTML(html) {
    return Safe.html(html).replace(/<br\s*\/?\s*>/gi,'\n').split('\n').map(Safe.plain).join('\n');
  }
  function linkSelection(el, plain) {
    const range=selectionInside(el),href=Safe.url(plain.trim());
    if(!range||range.collapsed||!href||/\s/.test(plain.trim()))return false;
    if(!document.execCommand('createLink',false,href))return false;
    changed(el);return true;
  }
  function paste(e,el,{plain=false,rich=false,multiline=true}={}) {
    if(e.defaultPrevented||el.getAttribute('contenteditable')!=='true')return;
    e.preventDefault();e.stopPropagation();
    const data=e.clipboardData;
    if(!data||!selectionInside(el))return;
    const rawHTML=data.getData('text/html'),rawText=data.getData('text/plain');
    const text=rawText||textFromHTML(rawHTML);
    if(!text&&!rawHTML){if(data.files?.length)UI.toast('이 입력 영역은 텍스트를 받습니다. 이미지는 이미지 블록에서 추가하세요.','info',6000);return;}
    if(!plain&&linkSelection(el,text))return;
    let value;
    if(plain)value=multiline?text:text.replace(/[\r\n]+/g,' ');
    else value=rawHTML?(rich?Safe.rich(rawHTML):Safe.html(rawHTML)):Safe.escape(text.replace(/\r\n?/g,'\n')).replace(/\n/g,'<br>');
    if(!multiline&&!plain)value=value.replace(/<br\s*\/?\s*>/gi,' ');
    if(!value&&text)value=plain?text:Safe.escape(text).replace(/\n/g,'<br>');
    if(value)insert(el,value,{plain});
    if(rawHTML&&/<(?:img|video|audio|iframe)\b/i.test(rawHTML))UI.toast('텍스트와 서식을 붙여넣었습니다. 이미지·동영상은 해당 블록으로 별도 추가하세요.','info',6000);
  }
  function bind(el, options={}) {
    if(el.getAttribute('contenteditable')!=='true')return;
    el.addEventListener('paste',e=>paste(e,el,options));
    for(const type of ['copy','cut'])el.addEventListener(type,e=>{
      const range=selectionInside(el);if(!range||range.collapsed)return;
      e.stopPropagation();
      if(!e.clipboardData?.setData)return;
      const container=document.createElement('div');container.appendChild(range.cloneContents());
      e.clipboardData.setData('text/plain',window.getSelection().toString());
      e.clipboardData.setData('text/html',options.plain?Safe.escape(window.getSelection().toString()):Safe.rich(container.innerHTML));
      e.preventDefault();
      if(type==='cut') {
        if(!document.execCommand('delete'))range.deleteContents();
        changed(el);
      }
    });
    el.addEventListener('keydown',e=>{
      if(e.isComposing||e.keyCode===229)return;
      if(e.key==='Backspace'||e.key==='Delete')e.stopPropagation();
      const item=window.getSelection()?.anchorNode?.parentElement?.closest('li');
      if(options.rich&&e.key==='Tab'&&item&&el.contains(item)) {
        e.preventDefault();e.stopPropagation();indentList(el,item,e.shiftKey);
      }
    });
  }
  function indentList(el,item,outdent) {
    const range=selectionInside(el);if(!range)return;
    const startNode=range.startContainer,endNode=range.endContainer,start=range.startOffset,end=range.endOffset;
    if(!item.contains(startNode)||!item.contains(endNode))return;
    const list=item.parentElement;
    if(!list||!['UL','OL'].includes(list.tagName))return;
    if(outdent){
      const parentItem=list.parentElement;
      if(parentItem.tagName!=='LI'||!el.contains(parentItem.parentElement))return;
      parentItem.after(item);if(!list.children.length)list.remove();
    }else{
      const previous=item.previousElementSibling;if(previous?.tagName!=='LI')return;
      let nested=Array.from(previous.children).find(c=>c.tagName===list.tagName);
      if(!nested){nested=document.createElement(list.tagName.toLowerCase());previous.appendChild(nested);}
      nested.appendChild(item);
    }
    range.setStart(startNode,start);range.setEnd(endNode,end);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);
    changed(el);
  }
  function attach(holder) {
    holder.addEventListener('keydown',e=>{
      if(!(e.ctrlKey||e.metaKey)||e.isComposing)return;
      const el=e.target.closest?.('[contenteditable="true"]');
      if(!el||el.closest('.table-block')||!selectionInside(el))return;
      const key=e.key.toLowerCase();
      if(!e.altKey&&((key==='u'&&!e.shiftKey)||(key==='s'&&e.shiftKey))){
        e.preventDefault();e.stopPropagation();document.execCommand(key==='u'?'underline':'strikeThrough');changed(el);return;
      }
      if(e.altKey&&e.key.toLowerCase()==='t'){
        const arrows=Array.from(holder.querySelectorAll('.toggle-block__arrow'));
        if(!arrows.length)return;
        e.preventDefault();e.stopPropagation();const open=arrows.some(a=>a.getAttribute('aria-expanded')==='false');
        for(const arrow of arrows)if((arrow.getAttribute('aria-expanded')==='true')!==open)arrow.click();
      }
    },true);
    holder.addEventListener('paste',e=>{
      if(e.defaultPrevented)return;
      const el=e.target.closest?.('[contenteditable="true"]');
      if(!el||!holder.contains(el)||el.closest('.table-block')||el.matches('.image-block__caption,.bookmark-block__title'))return;
      if(linkSelection(el,e.clipboardData?.getData('text/plain')||'')){e.preventDefault();e.stopPropagation();}
    },true);
  }
  return {bind,paste,insert,selectionInside,indentList,attach};
})();

class StrikethroughTool {
  static get isInline(){return true;}
  static get title(){return '취소선';}
  static get sanitize(){return {s:true,strike:true,del:true};}
  render(){return {icon:'<svg width="16" height="16" viewBox="0 0 16 16"><path d="M12 3H6C2 3 3 7 7 7h2c4 0 4 6 0 6H4M1 8h14" fill="none" stroke="currentColor"/></svg>',name:'취소선',onActivate:()=>{document.execCommand('strikeThrough');Workspace.markDirty();Safe.event('editorChanged');},isActive:()=>document.queryCommandState('strikeThrough')};}
}
