/* Bounded, memoized formula evaluator. Blank/text values remain typed until arithmetic. */
const Formula=(()=>{
  const fail=code=>{throw Object.assign(new Error(code),{code});};
  const colName=i=>{let s='';for(i++;i>0;i=Math.floor((i-1)/26))s=String.fromCharCode(65+(i-1)%26)+s;return s;};
  const colIndex=s=>[...s.toUpperCase()].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)-1;
  const isFormula=v=>typeof v==='string'&&v.trim().startsWith('=');
  const numeric=s=>/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(s)||/^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$/.test(s);
  const number=v=>v===null?0:typeof v==='number'?v:fail('#VALUE!');
  const finite=v=>typeof v==='number'&&!Number.isFinite(v)?fail('#NUM!'):v;
  function tokens(src){
    if(src.length>8192)fail('#LIMIT!');const out=[];let i=0;
    while(i<src.length){const s=src.slice(i);let m;if(/^\s/.test(s)){i++;continue;}
      if((m=/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/.exec(s)))out.push({t:'n',v:Number(m[0])});
      else if((m=/^\$?([A-Za-z]+)\$?([1-9]\d*)/.exec(s)))out.push({t:'cell',r:Number(m[2])-1,c:colIndex(m[1])});
      else if((m=/^[A-Za-z]+/.exec(s)))out.push({t:'fn',v:m[0].toUpperCase()});
      else if((m=/^#(?:REF!|VALUE!|DIV\/0!|NUM!|CYCLE!|LIMIT!)/.exec(s)))out.push({t:'err',v:m[0]});
      else if('+-*/(),:'.includes(s[0])){m=[s[0]];out.push({t:s[0]});}else fail('#ERROR!');
      i+=m[0].length;if(out.length>2048)fail('#LIMIT!');
    }return out;
  }
  function context(grid){
    const memo=new Map(),visiting=new Set();let budget=200000,depth=0;const cols=grid.reduce((n,r)=>Math.max(n,r.length),0);
    const spend=()=>{if(--budget<0)fail('#LIMIT!');};
    const valid=(r,c)=>{if(!Number.isSafeInteger(r)||!Number.isSafeInteger(c)||r<0||c<0||r>=grid.length||c>=cols)fail('#REF!');};
    function cell(r,c){spend();valid(r,c);const k=r+','+c;if(memo.has(k)){const v=memo.get(k);if(v instanceof Error)throw v;return v;}if(visiting.has(k))fail('#CYCLE!');if(depth>=128)fail('#LIMIT!');
      visiting.add(k);depth++;try{const raw=String(grid[r]?.[c]??'').trim();let v=raw===''?null:raw.startsWith("'")?raw.slice(1):isFormula(raw)?evaluate(raw.slice(1)):numeric(raw)?finite(Number(raw.replace(/,/g,''))):raw;memo.set(k,v);return v;}
      catch(e){memo.set(k,e);throw e;}finally{visiting.delete(k);depth--;}
    }
    function evaluate(src){const ts=tokens(src);let p=0,nesting=0;const peek=t=>ts[p]?.t===t;const next=()=>ts[p++];const expect=t=>{if(!peek(t))fail('#ERROR!');return next();};
      function expr(){let v=term();while(peek('+')||peek('-')){const op=next().t,b=term();v=finite(op==='+'?number(v)+number(b):number(v)-number(b));}return v;}
      function term(){let v=factor();while(peek('*')||peek('/')){const op=next().t,b=number(factor());if(op==='/'&&b===0)fail('#DIV/0!');v=finite(op==='*'?number(v)*b:number(v)/b);}return v;}
      function factor(){spend();if(++nesting>128)fail('#LIMIT!');try{
        if(peek('+')||peek('-')){const sign=next().t;return(sign==='-'?-1:1)*number(factor());}
        if(peek('(')){next();const v=expr();expect(')');return v;}
        if(peek('n'))return finite(next().v);if(peek('err'))fail(next().v);if(peek('cell')){const t=next();return cell(t.r,t.c);}
        if(peek('fn')){const fn=next().v;expect('(');const vals=[];if(!peek(')')){do{if(peek(','))next();if(peek('cell')&&ts[p+1]?.t===':'){const a=next();next();const b=expect('cell');valid(a.r,a.c);valid(b.r,b.c);const count=(Math.abs(a.r-b.r)+1)*(Math.abs(a.c-b.c)+1);if(count>50000||count>budget)fail('#LIMIT!');for(let r=Math.min(a.r,b.r);r<=Math.max(a.r,b.r);r++)for(let c=Math.min(a.c,b.c);c<=Math.max(a.c,b.c);c++)vals.push(cell(r,c));}else vals.push(expr());}while(peek(','));}expect(')');return calc(fn,vals);}
        fail('#ERROR!');
      }finally{nesting--;}}
      const result=expr();if(p!==ts.length)fail('#ERROR!');return result;
    }
    function calc(fn,vals){const ns=vals.filter(v=>typeof v==='number');const sum=()=>ns.reduce((a,b)=>a+b,0);let v;
      switch(fn){case'SUM':v=sum();break;case'COUNT':v=ns.length;break;case'AVG':case'AVERAGE':if(!ns.length)fail('#DIV/0!');v=sum()/ns.length;break;case'MIN':v=ns.length?ns.reduce((a,b)=>Math.min(a,b)):0;break;case'MAX':v=ns.length?ns.reduce((a,b)=>Math.max(a,b)):0;break;case'PRODUCT':v=ns.length?ns.reduce((a,b)=>a*b,1):0;break;
      case'ABS':if(vals.length!==1)fail('#VALUE!');v=Math.abs(number(vals[0]));break;
      case'ROUND':{if(vals.length<1||vals.length>2)fail('#VALUE!');const x=number(vals[0]),d=number(vals[1]??0);if(!Number.isInteger(d)||Math.abs(d)>100)fail('#NUM!');const p=10**d;v=Math.sign(x)*Math.round((Math.abs(x)+Number.EPSILON)*p)/p;break;}default:fail('#NAME?');}return finite(v);
    }
    function display(r,c){const raw=String(grid[r]?.[c]??'');if(raw.startsWith("'"))return raw.slice(1);if(!isFormula(raw))return raw;try{return fmt(cell(r,c));}catch(e){return e.code||'#ERROR!';}}
    return {cell,evaluate,display};
  }
  const fmt=v=>v===null?'0':typeof v==='number'?String(Number(v.toPrecision(12))):String(v);
  function adjustReferences(grid,axis,index,delta=-1){return grid.map(row=>row.map(raw=>!isFormula(raw)?raw:raw.replace(/(\$?)([A-Za-z]+)(\$?)([1-9]\d*)/g,(all,ac,letters,ar,n)=>{let r=Number(n)-1,c=colIndex(letters);let x=axis==='row'?r:c;if(delta<0&&x===index)return '#REF!';if(x>=index)x+=delta;if(axis==='row')r=x;else c=x;return ac+colName(c)+ar+(r+1);})));}
  return {colName,colIndex,isFormula,fmt,context,adjustReferences,cellNumber:(g,r,c)=>context(g).cell(r,c),evalFormula:(g,s)=>context(g).evaluate(s),displayValue:(g,r,c)=>context(g).display(r,c),computeGrid:g=>{const ctx=context(g);return g.map((row,r)=>row.map((_,c)=>ctx.display(r,c)));}};
})();
