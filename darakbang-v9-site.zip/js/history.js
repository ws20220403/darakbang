/* Body-only undo. A detached editor generation makes late render completion harmless. */
const History=(()=>{
  let entries=[],index=-1,busy=false,applying=false,generation=0,pageId=null;
  const MAX_BYTES=12*1024*1024,MAX_COUNT=60;
  const signature=data=>JSON.stringify((data.blocks||[]).map(b=>[b.type,b.data,b.tunes||{}]));
  const emit=()=>Safe.event('historyChanged',{canUndo:canUndo(),canRedo:canRedo()});
  const canUndo=()=>!busy&&index>0,canRedo=()=>!busy&&index>=0&&index<entries.length-1;
  function reset(data={blocks:[]}){generation++;pageId=Workspace.getCurrentPageId();entries=[];index=-1;busy=false;applying=false;record(data);}
  function record(data){
    if(applying||!data?.blocks)return;const sig=signature(data);if(entries[index]?.sig===sig)return;
    entries=entries.slice(0,index+1);entries.push({data:Safe.clone(data),sig,bytes:sig.length*2+JSON.stringify(data).length*2});
    let bytes=entries.reduce((n,e)=>n+e.bytes,0);while(entries.length>1&&(entries.length>MAX_COUNT||bytes>MAX_BYTES))bytes-=entries.shift().bytes;
    index=entries.length-1;emit();
  }
  async function apply(direction){
    if(busy||applying)return;const g=generation,id=pageId;let applied=false,previous=null;busy=true;emit();
    try{
      const current=await EditorManager.getEditorData();if(g!==generation||id!==Workspace.getCurrentPageId())return;previous=current;record(current);
      const target=index+direction;if(target<0||target>=entries.length)return;
      applying=true;await EditorManager.replaceData(entries[target].data,{pageId:id,generation:EditorManager.generation});
      if(g!==generation||id!==Workspace.getCurrentPageId())return;
      index=target;Workspace.markDirty(id);try{EditorManager.instance.caret.setToBlock(0,'end');}catch{}
      applied=true;
    }catch(e){if(g===generation&&id===Workspace.getCurrentPageId()&&previous&&!EditorManager.instance){try{await EditorManager.init({id,editorData:previous});}catch{}}if(e.name!=='AbortError')Safe.report(e);}
    finally{if(g===generation){applying=false;busy=false;emit();if(applied)Safe.event('editorChanged',{fromHistory:true});}}
  }
  return {reset,record,undo:()=>apply(-1),redo:()=>apply(1),canUndo,canRedo,isApplying:()=>applying};
})();
