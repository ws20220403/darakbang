/* Reviewable multiple-block moves use one Workspace transaction. */
const BlockActions=(()=>{
  let busy=false;
  const node=(tag,text)=>{const el=document.createElement(tag);if(text!=null)el.textContent=text;return el;};
  const labelOf=b=>b.type==='recipe'?('레시피: '+(b.data.name||'메뉴명 없음')):b.type==='toggle'?(Safe.plain(b.data.title)||'제목 없는 토글'):b.type==='pageLink'?('문서 링크: '+(Workspace.getPageMeta(b.data.pageId)?.title||'연결할 문서 선택')):(Exporter.plainText({blocks:[b]}).slice(0,100)||({image:'이미지',attachment:'첨부파일',table:'표'}[b.type]||'빈 블록'));
  function init(){
    for(const id of ['btn-save','btn-save-mobile']){const save=document.getElementById(id);if(!save||document.getElementById(id+'-blocks'))continue;const b=node('button','블록 이동');b.id=id+'-blocks';b.type='button';b.className='block-actions-open';b.onclick=()=>open().catch(Safe.report);save.before(b);}
  }
  async function open(){
    if(busy||document.querySelector('.block-move-dialog'))return;
    const sourceId=Workspace.getCurrentPageId();if(!sourceId){UI.toast('이동할 블록이 있는 문서를 먼저 여세요.','info');return;}
    if(Workspace.isDirty()&&!await App.save({silent:true}))return;
    const source=await Workspace.loadPage(sourceId),overlay=node('div'),card=node('section'),header=node('header'),title=node('h2','블록 이동'),close=node('button','닫기'),description=node('p','이동할 블록을 선택하세요. 토글을 선택하면 안의 내용도 함께 이동합니다.'),list=node('div'),destination=node('select'),toggle=node('select'),status=node('p'),apply=node('button','선택한 블록 이동');
    overlay.className='recovery-overlay block-move-dialog';card.className='recovery-card';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','블록 이동');destination.setAttribute('aria-label','이동할 문서');toggle.setAttribute('aria-label','문서 안 위치');list.className='block-move-list';status.setAttribute('role','status');close.type=apply.type='button';
    const opener=document.activeElement;let release,sequence=0;
    const dismiss=()=>{if(busy)return;sequence++;overlay.remove();release?.();document.removeEventListener('keydown',escape,true);opener?.focus();};
    const escape=e=>{if(e.key==='Escape'){e.stopPropagation();dismiss();}};close.onclick=dismiss;overlay.onclick=e=>{if(e.target===overlay)dismiss();};document.addEventListener('keydown',escape,true);
    Safe.walkBlocks(source.editorData.blocks,(b,owner,depth)=>{const row=node('label'),input=node('input'),label=node('span',labelOf(b));input.type='checkbox';input.value=b.id;row.style.paddingLeft=(Math.min(depth,4)*12)+'px';row.append(input,label);list.append(row);});
    for(const meta of Workspace.getAllPagesMeta()){let path=meta.title;try{path=Workspace.getAncestors(meta.id).map(p=>p.title).concat(meta.title).join(' › ');}catch{}const option=node('option',path);option.value=meta.id;destination.append(option);}destination.value=sourceId;
    const loadTargets=async()=>{const seq=++sequence;toggle.disabled=apply.disabled=true;toggle.replaceChildren();try{const page=await Workspace.loadPage(destination.value);if(seq!==sequence)return;const top=node('option','문서 맨 아래');top.value='';toggle.append(top);Safe.walkBlocks(page.editorData.blocks,(b,owner,depth)=>{if(b.type==='toggle'){const option=node('option','　'.repeat(depth)+'토글: '+(Safe.plain(b.data.title)||'제목 없음'));option.value=b.id;toggle.append(option);}});toggle.disabled=apply.disabled=false;status.textContent='';}catch(e){status.textContent=e.message;}};
    destination.onchange=loadTargets;
    apply.onclick=async()=>{if(busy)return;const ids=Array.from(list.querySelectorAll('input:checked')).map(x=>x.value);if(!ids.length){status.textContent='이동할 블록을 선택하세요.';return;}busy=true;apply.disabled=destination.disabled=toggle.disabled=close.disabled=true;status.textContent='이동하는 중…';try{const n=await Workspace.moveBlocks(sourceId,ids,destination.value,toggle.value||null);busy=false;dismiss();Sidebar.render();if(destination.value===Workspace.getCurrentPageId())await App.reloadCurrent();else await App.navigateToPage(destination.value);UI.toast(n+'개 블록을 이동했습니다. 버전 기록에서 이전 내용을 확인할 수 있습니다.','success');}catch(e){status.textContent=e.message;}finally{busy=false;if(overlay.isConnected)apply.disabled=destination.disabled=toggle.disabled=close.disabled=false;}};
    header.append(title,close);card.append(header,description,list,node('p','이동할 위치'),destination,toggle,status,apply,node('small','문서 링크를 옮겨도 사이드바의 문서 계층은 유지됩니다.'));overlay.append(card);document.body.append(overlay);release=UI.trapFocus(overlay);await loadTargets();close.focus();
  }
  return {init,open};
})();


