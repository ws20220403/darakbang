/**
 * app.js — 앱 진입점 및 주요 흐름 조율
 *
 * 실행 순서:
 * 1. Google OAuth 초기화
 * 2. 로그인 여부 확인
 *    - 로그인: Drive 초기화 → 앱 화면
 *    - 미로그인: 로그인 화면
 * 3. 페이지 탐색, 저장, 커버 이미지 관리
 */

const App = (() => {

  let _currentCoverImageId = null;
  let _globalEventsBound   = false;  // 중복 바인딩 방지
  let _coverResizeHandler  = null;
  let _autosaveTimer       = null;   // 디바운스 자동저장
  const AUTOSAVE_DELAY     = 750;   // ms
  let _lastChangeAt=0;
  let _requestSeq=0;
  let _activeData=null, _navSeq=0, _saveFlight=null, _saveRequested=false, _draftTimer=null, _maxWaitTimer=null, _refreshTimer=null;

  /* =========================================================
     자동 저장 / 저장 상태 표시
  ========================================================= */
  function _setSaveStatus(text) {
    const el = document.getElementById('save-status');
    if (el) el.textContent = text || '';
    const mobile=document.getElementById('save-status-mobile');if(mobile)mobile.textContent=text||'';
  }

  function _scheduleAutosave(event) {
    if(!Workspace.getCurrentPageId()||History.isApplying())return;
    if(!event?.detail?.fromCore||!_autosaveTimer||Date.now()-_lastChangeAt>AUTOSAVE_DELAY)_lastChangeAt=Date.now();
    clearTimeout(_draftTimer);
    _draftTimer=setTimeout(()=>_captureSnapshot().then(s=>s&&Workspace.persistDraft(s.page.id,s.page,s.revision)).catch(Safe.report),120);
    clearTimeout(_autosaveTimer);
    _autosaveTimer=setTimeout(()=>{_autosaveTimer=null;if(Workspace.isDirty())_savePage({silent:true});},Math.max(0,AUTOSAVE_DELAY-(Date.now()-_lastChangeAt)));
    if(!_maxWaitTimer)_maxWaitTimer=setTimeout(()=>{_maxWaitTimer=null;if(Workspace.isDirty())_savePage({silent:true});},5000);
    if(_saveFlight)_saveRequested=true;
  }
  function _stopTasks(session=true){clearTimeout(_autosaveTimer);clearTimeout(_draftTimer);clearTimeout(_maxWaitTimer);if(session)clearInterval(_refreshTimer);_maxWaitTimer=null;_requestSeq++;_navSeq++;_activeData=null;}
  async function _captureSnapshot(){
    const id=Workspace.getCurrentPageId(),ed=EditorManager.instance,seq=_navSeq;
    if(!id||!ed||!_activeData)return null;
    const revision=Workspace.getEditRevision(id),page={...Safe.clone(_activeData),id,title:document.getElementById('page-title-input').textContent.trim()||'제목 없음',icon:document.getElementById('page-icon-display').textContent||'📄',coverImageId:_currentCoverImageId};
    page.editorData=await EditorManager.getEditorData();
    if(!page.editorData)throw new Error('편집 내용을 읽지 못했습니다. 문서를 유지한 채 다시 시도하세요.');
    if(seq!==_navSeq||id!==Workspace.getCurrentPageId()||ed!==EditorManager.instance)return null;
    return {page,revision};
  }

  /* =========================================================
     앱 시작
  ========================================================= */
  async function start() {
    // 테마 초기화 (CSS 적용 전에)
    UI.initTheme();

    // Demo controls become ready immediately; Google is initialized only for an actual connection.
    _showLoginScreen();
    Auth.init().catch(()=>{});

    // 로그인(또는 데모) 여부 확인
    if (Auth.isLoggedIn()) {
      Storage.setMode(Auth.isDemo() ? 'demo' : 'drive');
      await _bootApp();
    } else {
      _showLoginScreen();
    }
  }

  /* =========================================================
     로그인 화면
  ========================================================= */
  function _showLoginScreen() {
    document.getElementById('login-screen')?.classList.remove('hidden');
    document.getElementById('loading-screen')?.classList.add('hidden');
    document.getElementById('app')?.classList.add('hidden');

    // [버그수정] { once: true } 제거 → 로그아웃 후 재로그인 시에도 작동
    // 대신 data 속성으로 중복 바인딩 방지
    const btn = document.getElementById('btn-google-login');
    if (btn && !btn.dataset.listenerBound) {
      btn.dataset.listenerBound = '1';
      btn.addEventListener('click', async () => {
        // Client ID 미설정이면 구글의 400 오류 대신 설정 모달을 열어 안내
        if (!Auth.isConfigured()) {
          UI.toast('먼저 “구글 드라이브 연결 설정”에서 Client ID를 입력해 주세요.', 'info', 5000);
          _openGoogleSetup();
          return;
        }
        const accountInput=document.getElementById('login-account-email');
        try{Auth.setLoginHint(accountInput?.value||'');}catch(e){UI.toast(e.message,'warning');accountInput?.focus();return;}
        btn.disabled = true;
        if(accountInput)accountInput.disabled=true;
        const loginStatus=document.getElementById('login-status');
        if(loginStatus)loginStatus.textContent='Google 계정 선택 창의 응답을 기다리는 중입니다. 새 창에서 로그인을 완료하세요.';
        // "로그인 상태 유지" 선택 반영 (토큰 저장 위치 결정)
        Auth.setPersist(!!document.getElementById('chk-stay')?.checked);
        try {
          await Auth.login();
          Storage.setMode('drive');
          await _bootApp();
        } catch (e) {
          console.error('로그인 실패:', e);
          btn.disabled = false;
          if(loginStatus)loginStatus.textContent=e.message?.includes('초과')||e.message?.includes('popup')?'로그인 창의 응답을 받지 못했습니다. 팝업 허용 여부를 확인하거나, Chrome·Edge에서 이 사이트 주소를 직접 열어 다시 시도하세요.':(e.message||'로그인하지 못했습니다. 다시 시도하세요.');
          if(accountInput)accountInput.disabled=false;
          if (e.message?.includes('popup_closed') || e.message?.includes('popup_failed') || e.message?.includes('user_cancelled')) {
            UI.toast('로그인 창이 닫혔습니다. 다시 시도해주세요.', 'warning');
          } else {
            UI.toast('로그인에 실패했습니다. 다시 시도해주세요.', 'error');
          }
        }
      });
    } else if (btn) {
      // 로그아웃 후 재방문 시 버튼 다시 활성화
      btn.disabled = false;
    }

    // 데모로 둘러보기 (OAuth 불필요)
    const demoBtn = document.getElementById('btn-demo-login');
    if (demoBtn && !demoBtn.dataset.listenerBound) {
      demoBtn.dataset.listenerBound = '1';
      demoBtn.addEventListener('click', async () => {
        demoBtn.disabled = true;
        Auth.enterDemo();
        Storage.setMode('demo');
        try {
          await _bootApp();
        } catch (e) {
          console.error('데모 시작 실패:', e);
          demoBtn.disabled = false;
          UI.toast('데모를 시작하지 못했습니다.', 'error');
        }
      });
    } else if (demoBtn) {
      demoBtn.disabled = false;
    }

    const accountInput=document.getElementById('login-account-email');
    if(accountInput){accountInput.value=Auth.getLoginHint();accountInput.disabled=false;}

    // "로그인 상태 유지" 체크박스 — 저장된 설정 반영
    const stay = document.getElementById('chk-stay');
    if (stay) stay.checked = Auth.getPersist();

    // 구글 드라이브 연결 설정 모달
    const setupBtn = document.getElementById('btn-google-setup');
    if (setupBtn && !setupBtn.dataset.listenerBound) {
      setupBtn.dataset.listenerBound = '1';
      setupBtn.addEventListener('click', _openGoogleSetup);
    }
  }

  /* =========================================================
     구글 연결 설정 (배포 후 코드 수정 없이 Client ID 입력)
  ========================================================= */
  function _openGoogleSetup() {
    const overlay  = document.getElementById('modal-gsetup');
    const input    = document.getElementById('gsetup-input');
    const originEl = document.getElementById('gsetup-origin');
    const btnSave  = document.getElementById('gsetup-save');
    const btnCancel = document.getElementById('gsetup-cancel');
    if (!overlay) return;

    if (originEl) originEl.textContent = window.location.origin;
    input.value = Auth.isConfigured() ? Auth.getClientId() : '';
    const release=UI.trapFocus(overlay);
    overlay.classList.remove('hidden');
    overlay.removeAttribute('aria-hidden');
    input.focus();
    input.select();

    const close = () => {
      overlay.classList.add('hidden');
      overlay.setAttribute('aria-hidden', 'true');
      release();btnSave.removeEventListener('click', onSave);
      btnCancel.removeEventListener('click', close);
      overlay.removeEventListener('click', onOverlay);
      document.removeEventListener('keydown', onKey);
    };
    const onOverlay = (e) => { if (e.target === overlay) close(); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    const onSave = () => {
      const id = input.value.trim();
      if (id && !id.includes('.apps.googleusercontent.com')) {
        UI.toast('형식이 올바르지 않습니다. “…apps.googleusercontent.com” 형태여야 합니다.', 'warning', 5000);
        return;
      }
      Auth.setClientId(id);
      close();
      if (Auth.isConfigured()) {
        UI.toast('저장됐습니다. 잠시 후 새로고침 → “구글 계정으로 로그인”을 눌러주세요.', 'success', 4000);
        setTimeout(() => location.reload(), 900);
      } else {
        UI.toast('연결 설정을 비웠습니다.', 'info');
      }
    };

    btnSave.addEventListener('click', onSave);
    btnCancel.addEventListener('click', close);
    overlay.addEventListener('click', onOverlay);
    document.addEventListener('keydown', onKey);
  }

  /* =========================================================
     앱 부팅 (로그인 후)
  ========================================================= */
  async function _bootApp() {
    _showLoading('다락방을 열고 있습니다...');

    try {
      const user = await Auth.fetchUserInfo();
      Storage.setAccount(user.id);
      await Workspace.init();
      _updateUserProfile(user);

      // 앱 화면 전환
      _showApp();

      // 데모 모드 배지 표시
      document.getElementById('demo-badge')?.classList.toggle('hidden', !Auth.isDemo());
      const logoutBtn = document.getElementById('btn-logout');
      if (logoutBtn) logoutBtn.title = Auth.isDemo() ? '데모 종료' : '로그아웃';

      // UI 초기화 (한 번만)
      UI.initEmojiPicker();
      UI.initSidebarResize();
      const mobileSidebar = UI.initMobileSidebar();

      // 사이드바 초기화
      Sidebar.init();

      // 전역 이벤트 바인딩 (중복 방지)
      if (!_globalEventsBound) {
        _bindGlobalEvents(mobileSidebar);
        _globalEventsBound = true;
      }

      Recovery.init();
      BlockActions.init();
      clearInterval(_refreshTimer);
      _refreshTimer=setInterval(()=>{if(document.visibilityState==='visible'&&UI.isOnline()&&!_saveFlight)Workspace.refresh().catch(()=>{});},15000);
      showWelcome();
      const drafts=await Workspace.drafts();
      if(drafts.length)UI.toast(`기기에 보관된 초안 ${drafts.length}개가 있습니다. 보관함에서 확인하세요.`,'info',6000);

    } catch (e) {
      console.error('앱 초기화 실패:', e);
      const msg = e.message || '';
      if (msg.includes('401') || msg.includes('토큰') || msg.includes('token') || msg.includes('unauthorized')) {
        Auth.clearTokens();
        _showLoginScreen();
        UI.toast('세션이 만료됐습니다. 다시 로그인해주세요.', 'warning');
      } else {
        _showLoginScreen();
        UI.toast(`앱 초기화 실패: ${e.message}`, 'error', 8000);
      }
    }
  }

  /* =========================================================
     사용자 프로필 업데이트
  ========================================================= */
  function _updateUserProfile(user) {
    const avatar = document.getElementById('user-avatar');
    const name   = document.getElementById('user-name');
    const email  = document.getElementById('user-email');

    if (avatar) {
      if (user.picture) {
        avatar.src = user.picture;
        avatar.style.display = '';
      } else {
        avatar.style.display = 'none';
      }
      avatar.onerror = () => { avatar.style.display = 'none'; };
    }
    if (name)  name.textContent  = user.name  || '사용자';
    if (email) email.textContent = user.email || '';
  }

  /* =========================================================
     화면 전환 헬퍼
  ========================================================= */
  function _showLoading(msg = '') {
    document.getElementById('login-screen')?.classList.add('hidden');
    document.getElementById('loading-screen')?.classList.remove('hidden');
    document.getElementById('app')?.classList.add('hidden');
    const msgEl = document.getElementById('loading-message');
    if (msgEl && msg) msgEl.textContent = msg;
  }

  function _showApp() {
    document.getElementById('login-screen')?.classList.add('hidden');
    document.getElementById('loading-screen')?.classList.add('hidden');
    document.getElementById('app')?.classList.remove('hidden');
  }

  function _showError(msg) {
    document.getElementById('loading-screen')?.classList.add('hidden');
    document.getElementById('login-screen')?.classList.remove('hidden');
    document.getElementById('app')?.classList.add('hidden');
    UI.toast(msg, 'error', 8000);
  }

  function showWelcome() {
    _stopTasks(false);
    document.getElementById('welcome-screen')?.classList.remove('hidden');
    document.getElementById('page-editor-area')?.classList.add('hidden');
    Workspace.setCurrentPageId(null);
    EditorManager.destroy();
    const mobileTitleEl = document.getElementById('mobile-page-title');
    if (mobileTitleEl) mobileTitleEl.textContent = '다락방';
    History.reset(null);                 // [v6] 되돌리기 기록 비우기(메모리 정리)
    Sidebar.setActivePage(null);
  }

  /* [v6] 되돌리기/복원 버튼 활성/비활성 갱신 (History 상태 변화 시) */
  function _updateHistoryButtons(e) {
    const canUndo = e?.detail?.canUndo ?? false;
    const canRedo = e?.detail?.canRedo ?? false;
    ['btn-undo', 'btn-undo-mobile'].forEach(id => { const b = document.getElementById(id); if (b) b.disabled = !canUndo; });
    ['btn-redo', 'btn-redo-mobile'].forEach(id => { const b = document.getElementById(id); if (b) b.disabled = !canRedo; });
  }

  /* =========================================================
     전역 이벤트
  ========================================================= */
  function _bindGlobalEvents(mobileSidebar) {
    document.addEventListener('darakbang:authRequired',()=>Recovery.showReconnect());
    document.addEventListener('darakbang:syncStatus',e=>_setSaveStatus(e.detail.message));
    document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'&&Workspace.isDirty())_captureSnapshot().then(s=>s&&Workspace.persistDraft(s.page.id,s.page,s.revision)).catch(()=>{});});
    // 로그아웃
    document.getElementById('btn-logout')?.addEventListener('click', async () => {
      if (Workspace.isDirty()) {
        const action = await UI.confirmUnsaved();
        if (action === 'save' && !await _savePage()) return;
        else if (action === null) return; // 취소
      }
      _stopTasks();
      Workspace.reset();
      Drive.reset();
      Auth.logout();
      Workspace.markClean();
      EditorManager.destroy();
      _showLoginScreen();
    });

    // 테마 토글
    document.getElementById('btn-theme-toggle')?.addEventListener('click', UI.toggleTheme);

    // [v7] 단축키 · 편의기능 안내
    document.getElementById('btn-shortcuts')?.addEventListener('click', () => {
      if (typeof Shortcuts !== 'undefined') Shortcuts.open();
    });

    // 저장 버튼
    document.getElementById('btn-save')?.addEventListener('click', _savePage);
    document.getElementById('btn-save-mobile')?.addEventListener('click', _savePage);

    // Ctrl+S / Cmd+S
    document.addEventListener('keydown', (e) => {
      if (!e.defaultPrevented && !e.shiftKey && !e.altKey && (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        _savePage();
      }
    });

    // [v6] 되돌리기/복원 버튼(←/→, 데스크톱·모바일)
    const bindHist = (id, fn) => document.getElementById(id)?.addEventListener('click', (e) => { e.preventDefault(); fn(); });
    bindHist('btn-undo', () => History.undo());
    bindHist('btn-redo', () => History.redo());
    bindHist('btn-undo-mobile', () => History.undo());
    bindHist('btn-redo-mobile', () => History.redo());
    document.addEventListener('darakbang:historyChanged', _updateHistoryButtons);

    // [v6] Ctrl+Z 되돌리기 / Ctrl+Shift+Z·Ctrl+Y 복원
    //  - 제목·코드(textarea)·입력창은 브라우저 기본 실행취소를 그대로 둔다(세밀 편집 보존).
    //  - 본문 에디터 블록(문단/목록/표 등)과 포커스 없는 상태에선 문서 단위 되돌리기.
    document.addEventListener('keydown', (e) => {
      if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
      const k = e.key.toLowerCase();
      const isUndo = (k === 'z' && !e.shiftKey);
      const isRedo = (k === 'z' && e.shiftKey) || (k === 'y');
      if (!isUndo && !isRedo) return;
      if (!Workspace.getCurrentPageId()) return;
      const ae = document.activeElement;
      const tag = ae && ae.tagName;
      const nativeField = tag === 'INPUT' || tag === 'TEXTAREA' || (ae && ae.id === 'page-title-input');
      if (nativeField) return;
      e.preventDefault();
      if (isUndo) History.undo(); else History.redo();
    }, true);

    // 페이지 제목 입력
    const titleInput = document.getElementById('page-title-input');
    titleInput?.addEventListener('input', () => {
      Workspace.markDirty();
      const title = titleInput.textContent.trim();
      const mobileTitleEl = document.getElementById('mobile-page-title');
      if (mobileTitleEl) mobileTitleEl.textContent = title || '제목 없음';
      _updateSidebarTitle(Workspace.getCurrentPageId(), title);
      const currentCrumb=document.querySelector('#breadcrumb [aria-current="page"] .breadcrumb-text');
      if(currentCrumb)currentCrumb.textContent=title||'제목 없음';
      _scheduleAutosave();
    });

    // 에디터 내용 변경 → 자동 저장 예약 + (단어 수 + 본문→사이드바 즉시 동기화)
    document.addEventListener('darakbang:editorChanged', _scheduleAutosave);
    document.addEventListener('darakbang:editorChanged', _onEditorChanged);

    // 엔터 키로 에디터 포커스 이동
    titleInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        // Editor.js 첫 번째 contenteditable로 포커스
        const editorEl = document.getElementById('editorjs');
        const firstEditable = editorEl?.querySelector('[contenteditable="true"],textarea,input');
        if (firstEditable) firstEditable.focus();
      }
    });

    // 제목 붙여넣기 시 plain text만 허용
    titleInput?.addEventListener('paste', (e) => {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text/plain');
      document.execCommand('insertText', false, text.replace(/[\r\n]+/g, ' '));
    });

    // 페이지 아이콘 버튼
    document.getElementById('btn-page-icon')?.addEventListener('click', (e) => {
      e.currentTarget.setAttribute('data-emoji-trigger', '');
      UI.openEmojiPicker(e.currentTarget, (emoji) => {
        document.getElementById('page-icon-display').textContent = emoji;
        Workspace.markDirty();
        _scheduleAutosave();
      });
    });

    // 커버 이미지 버튼들
    document.getElementById('btn-add-cover')?.addEventListener('click', _triggerCoverUpload);
    document.getElementById('btn-change-cover')?.addEventListener('click', _triggerCoverUpload);
    document.getElementById('btn-remove-cover')?.addEventListener('click', _removeCover);
    document.getElementById('cover-file-input')?.addEventListener('change', _onCoverFileChange);

    // 탭 닫기 경고 (미저장 시)
    window.addEventListener('beforeunload', (e) => {
      if (Workspace.isDirty()) {
        e.preventDefault();
        e.returnValue = '저장되지 않은 내용이 있습니다.';
      }
    });

    // 네트워크 상태
    window.addEventListener('online',()=>{Workspace.retryPending().then(()=>{if(Workspace.isDirty())_savePage({silent:true});}).catch(Safe.report);});
    window.addEventListener('offline', () => UI.toast('인터넷 연결이 끊어졌습니다. 초안은 기기에 보관하고, 연결 후 동기화를 재시도합니다.', 'warning', 5000));

    document.getElementById('editorjs').addEventListener('input',()=>{if(!History.isApplying()){Workspace.markDirty();_scheduleAutosave();}},true);
    document.addEventListener('darakbang:saveState',e=>{
      if(e.detail.pageId!==Workspace.getCurrentPageId())return;
      const labels={dirty:'변경 있음',local:'기기에 보관됨',saving:'동기화 중',saved:Storage.isDemo()?'기기에 저장됨':'Drive 저장 완료',error:'동기화 대기 · 다시 시도',conflict:'충돌 · 버전 비교 필요'};
      _setSaveStatus(labels[e.detail.status]||'');
    });
    document.addEventListener('darakbang:activePageDeleted',()=>{showWelcome();Sidebar.render();});
    document.addEventListener('darakbang:workspaceChanged',async e=>{
      Sidebar.render();if(!e.detail.remote||!_activeData||_saveFlight)return;
      const id=Workspace.getCurrentPageId(),view=_navSeq;
      if(!Workspace.getPageMeta(id)){if(Workspace.isDirty())await _captureSnapshot().then(s=>s&&Workspace.persistDraft(id,s.page,s.revision));if(view!==_navSeq||id!==Workspace.getCurrentPageId())return;showWelcome();return;}
      try{const data=await Workspace.loadPage(id);if(view!==_navSeq||id!==Workspace.getCurrentPageId()||!_activeData)return;if(data._revision!==_activeData._revision){if(Workspace.isDirty())UI.toast('다른 탭/기기의 변경이 있습니다. 현재 초안은 보관됩니다.','warning');else await navigateToPage(id,{force:true});}}catch(e){if(e.name!=='AbortError')console.warn('동기화 화면 갱신 대기');}
    });
    // 모바일: 페이지 이동 시 사이드바 닫기
    if (mobileSidebar) {
      document.addEventListener('darakbang:pageChanged', () => {
        if (UI.isMobile()) mobileSidebar.closeSidebar();
      });
    }
  }

  /* =========================================================
     페이지 탐색
  ========================================================= */
  async function navigateToPage(pageId, options = {}) {
    if(!pageId||(!options.force&&pageId===Workspace.getCurrentPageId()))return false;
    const request=++_requestSeq;
    if(Workspace.isDirty()&&Workspace.getCurrentPageId()&&!await _savePage({silent:true}))return false;
    if(request!==_requestSeq)return false;
    try{
      let pageData=await Workspace.loadPage(pageId);if(request!==_requestSeq)return false;
      const draft=await Workspace.getDraft(pageId);if(request!==_requestSeq)return false;
      const comparable=p=>JSON.stringify([p.title,p.icon,p.coverImageId,p.editorData]);
      const restore=draft&&comparable(draft.page)!==comparable(pageData);
      if(restore)pageData={...draft.page,_revision:draft.baseRevision};
      clearTimeout(_autosaveTimer);clearTimeout(_draftTimer);const view=++_navSeq;
      Workspace.setCurrentPageId(pageId);_activeData=Safe.clone(pageData);
      await _renderPage(pageData,view);if(request!==_requestSeq)return false;
      if(restore){Workspace.markDirty();UI.toast('기기에 보관된 초안을 복구했습니다.','info');}
      Sidebar.setActivePage(pageId);Safe.event('pageChanged');return true;
    }catch(e){if(request===_requestSeq)Safe.report(e);return false;}
  }

  /* =========================================================
     페이지 렌더링
  ========================================================= */
  async function _renderPage(pageData, request=_navSeq) {
    const editorArea = document.getElementById('page-editor-area');
    editorArea.classList.remove('hidden');
    document.getElementById('welcome-screen')?.classList.add('hidden');

    // 제목
    const titleInput = document.getElementById('page-title-input');
    if (titleInput) {
      titleInput.textContent = pageData.title || '';
    }

    // 아이콘
    const iconDisplay = document.getElementById('page-icon-display');
    if (iconDisplay) {
      iconDisplay.textContent = pageData.icon || '📄';
    }

    // 모바일 타이틀
    const mobileTitleEl = document.getElementById('mobile-page-title');
    if (mobileTitleEl) {
      mobileTitleEl.textContent = pageData.title || '제목 없음';
    }

    // 커버 이미지 상태 초기화
    const isSubPage = !!pageData.parentId;
    _currentCoverImageId = isSubPage ? null : (pageData.coverImageId || null);
    document.getElementById('page-cover')?.classList.add('hidden');

    // 커버 추가 버튼 (커버 없을 때만 표시)
    const btnAddCover = document.getElementById('btn-add-cover');
    if (btnAddCover) {
      btnAddCover.classList.toggle('hidden', isSubPage || !!_currentCoverImageId);
    }

    // 브레드크럼
    _renderBreadcrumb(pageData.id);

    // 에디터 초기화
    await EditorManager.init(pageData);
    if(request!==_navSeq)return;
    Workspace.markClean(pageData.id);
    _renderCover(_currentCoverImageId,request).catch(Safe.report);

    // [v6] 되돌리기/복원 기록 초기화 — 로드한 본문을 첫 스냅샷으로(에디터 준비와 무관하게 즉시)
    History.reset(pageData.editorData);


  }

  /* =========================================================
     커버 이미지
  ========================================================= */
  async function _renderCover(fileId, request=_navSeq) {
    const coverEl  = document.getElementById('page-cover');
    const coverImg = document.getElementById('page-cover-img');
    if (!coverEl || !coverImg) return;

    if (!fileId) {
      coverEl.classList.add('hidden');
      return;
    }

    try {
      const blobUrl = await EditorManager.loadCoverImage(fileId);
      if(request!==_navSeq)return;
      if (blobUrl) {
        coverImg.src = blobUrl;
        _fitCoverToImage(coverEl, coverImg);
        coverEl.classList.remove('hidden');
      } else {
        coverEl.classList.add('hidden');
      }
    } catch (e) {
      console.warn('커버 이미지 로드 실패:', e);
      if(request!==_navSeq)return;
      coverEl.classList.add('hidden');
    }
  }

  function _fitCoverToImage(coverEl, coverImg) {
    const update = () => {
      const width = coverEl.clientWidth || 0;
      if (!width || !coverImg.naturalWidth || !coverImg.naturalHeight) return;
      const naturalHeight = width * (coverImg.naturalHeight / coverImg.naturalWidth);
      const maxHeight = width * (4 / 6);
      coverEl.style.setProperty('--cover-height', `${Math.min(naturalHeight, maxHeight)}px`);
    };

    coverImg.onload = update;
    if (_coverResizeHandler) window.removeEventListener('resize', _coverResizeHandler);
    _coverResizeHandler = update;
    window.addEventListener('resize', _coverResizeHandler);
    requestAnimationFrame(update);
  }

  function _triggerCoverUpload() {
    document.getElementById('cover-file-input')?.click();
  }

  async function _onCoverFileChange(e) {
    const pageId=Workspace.getCurrentPageId(),request=_navSeq;
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      UI.toast('파일이 10MB를 초과합니다.', 'warning');
      e.target.value = '';
      return;
    }

    const toastEl = UI.toast('커버 이미지를 업로드 중입니다...', 'info', 30000);
    try {
      const { fileId } = await Storage.uploadImage(file);
      if(request!==_navSeq||pageId!==Workspace.getCurrentPageId()){toastEl?.remove();e.target.value='';UI.toast('업로드된 커버는 보관함의 미사용 파일에서 확인할 수 있습니다.','info');return;}
      _currentCoverImageId = fileId;
      await _renderCover(fileId);
      document.getElementById('btn-add-cover')?.classList.add('hidden');
      Workspace.markDirty();
      _scheduleAutosave();
      toastEl?.remove();
      UI.toast('커버 이미지가 설정됐습니다.', 'success');
    } catch (err) {
      console.error('커버 업로드 실패:', err);
      toastEl?.remove();
      UI.toast('커버 이미지 업로드에 실패했습니다.', 'error');
    }

    // input 초기화 (같은 파일 재선택 허용)
    e.target.value = '';
  }

  function _removeCover() {
    _currentCoverImageId = null;
    document.getElementById('page-cover')?.classList.add('hidden');
    document.getElementById('btn-add-cover')?.classList.remove('hidden');
    Workspace.markDirty();
    _scheduleAutosave();
    UI.toast('커버 이미지가 제거됐습니다.', 'info');
  }

  /* =========================================================
     브레드크럼
  ========================================================= */
  function _renderBreadcrumb(pageId) {
    const nav = document.getElementById('breadcrumb');
    if (!nav) return;

    const ancestors = Workspace.getAncestors(pageId);
    const current   = Workspace.getPageMeta(pageId);
    nav.innerHTML = '';

    ancestors.forEach((meta) => {
      const span = document.createElement('span');
      span.className = 'breadcrumb-item';
      span.innerHTML = `<span class="breadcrumb-icon">${Safe.escape(meta.icon || '📄')}</span><span class="breadcrumb-text">${UI.escapeHtml(meta.title || '제목 없음')}</span>`;
      span.addEventListener('click', () => navigateToPage(meta.id));
      nav.appendChild(span);

      const sep = document.createElement('span');
      sep.className = 'breadcrumb-sep';
      sep.setAttribute('aria-hidden', 'true');
      sep.textContent = '/';
      nav.appendChild(sep);
    });

    if (current) {
      const span = document.createElement('span');
      span.className = 'breadcrumb-item breadcrumb-item-current';
      span.setAttribute('aria-current', 'page');
      span.innerHTML = `<span class="breadcrumb-icon">${Safe.escape(current.icon || '📄')}</span><span class="breadcrumb-text">${UI.escapeHtml(current.title || '제목 없음')}</span>`;
      nav.appendChild(span);
    }
  }

  /* =========================================================
     사이드바 제목 실시간 업데이트
  ========================================================= */
  function _updateSidebarTitle(pageId, title) {
    if (!pageId) return;
    document.querySelectorAll(`[data-page-id="${pageId}"] .nav-item-title`).forEach(el => {
      el.textContent = title || '제목 없음';
    });
  }

  /* =========================================================
     페이지 저장
  ========================================================= */
  async function _savePage(options={}) {
    if(_saveFlight){_saveRequested=true;return _saveFlight;}
    const id=Workspace.getCurrentPageId();if(!id)return false;
    _saveFlight=(async()=>{
      for(let attempt=0;attempt<3;attempt++){
        _saveRequested=false;const snapshot=await _captureSnapshot();if(!snapshot)return false;
        const p=snapshot.page;
        await Workspace.savePage(id,p.editorData,p.title,p.icon,p.coverImageId,{snapshot:p,revision:snapshot.revision});
        if(id!==Workspace.getCurrentPageId())return true;
        const saved=await Workspace.loadPage(id);_activeData={..._activeData,_revision:saved._revision};
        if(!_saveRequested&&!Workspace.isDirty(id))break;
      }
      if(!Workspace.isDirty(id)&&!options.silent)UI.toast(Storage.isDemo()?'기기에 저장했습니다.':'Drive에 저장했습니다.','success');
      return !Workspace.isDirty(id);
    })().catch(e=>{Safe.report(e);return false;}).finally(()=>{_saveFlight=null;clearTimeout(_maxWaitTimer);_maxWaitTimer=null;if(id===Workspace.getCurrentPageId()&&Workspace.isDirty(id)&&Workspace.getState(id).status==='dirty')_scheduleAutosave();});
    return _saveFlight;
  }

  /* =========================================================
     새 페이지 생성
  ========================================================= */
  async function createNewPage(parentId = null) {
    if (!UI.isOnline() && !Storage.isDemo()) {
      UI.toast('새 페이지를 만들려면 인터넷 연결이 필요합니다.', 'warning');
      return null;
    }

    try {
      if(Workspace.isDirty()&&!await _savePage({silent:true}))return null;
      const result = await Workspace.createPage(parentId);
      if (!result) return null;


      if(result.meta.parentId&&result.meta.parentId===Workspace.getCurrentPageId()){_activeData=await Workspace.loadPage(result.meta.parentId);Workspace.markClean();}
      Sidebar.render();
      await navigateToPage(result.meta.id);

      const titleInput=document.getElementById('page-title-input');
      if(Workspace.getCurrentPageId()===result.meta.id){titleInput?.focus();}

      return result;
    } catch (e) {
      console.error('페이지 생성 실패:', e);
      UI.toast('페이지를 만드는 데 실패했습니다.', 'error');
      return null;
    }
  }

  /* =========================================================
     페이지 복제 (요구사항 5)
  ========================================================= */
  let _duplicateFlight=false;
  async function duplicatePage(pageId) {
    if(_duplicateFlight)return;_duplicateFlight=true;
    try{
    // 현재 보고 있는 페이지를 복제할 때 미저장분이 반영되도록 먼저 저장
    if (Workspace.isDirty() && !await _savePage({ silent: true })) return;
    try {
      const result = await Workspace.duplicatePage(pageId);
      if (!result) { UI.toast('복제할 수 없습니다.', 'error'); return null; }
      // 하위 페이지 복제면 부모 본문 맨 아래에 링크를 추가해 사이드바/본문 일치 (요구사항 1·2)

      if(result.meta.parentId&&result.meta.parentId===Workspace.getCurrentPageId()){_activeData=await Workspace.loadPage(result.meta.parentId);Workspace.markClean();}
      Sidebar.render();
      await navigateToPage(result.meta.id);
      UI.toast('하위 문서 포함 '+result.count+'개 문서를 복제했습니다.', 'success');
      return result;
    } catch (e) {
      console.error('복제 실패:', e);
      UI.toast(e.message||'복제에 실패했습니다.', 'error');
      return null;
    }
    }finally{_duplicateFlight=false;}
  }

  /* =========================================================
     내보내기 (요구사항 5) — Markdown / 전체 백업(JSON)
  ========================================================= */
  function _downloadFile(filename, content, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function _safeFileName(name) {
    return (name || '제목 없음').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 80).trim() || 'page';
  }

  async function exportPageMarkdown(pageId) {
    if(pageId===Workspace.getCurrentPageId()&&Workspace.isDirty()&&!await _savePage({silent:true}))return;
    try {
      const data = await Workspace.loadPage(pageId);
      const meta = Workspace.getPageMeta(pageId);
      const title = (meta?.title || data?.title || '제목 없음');
      const md = Exporter.toMarkdown(title, data?.editorData);
      _downloadFile(_safeFileName(title) + '.md', md, 'text/markdown;charset=utf-8');
      UI.toast('Markdown 파일로 내보냈습니다.', 'success');
    } catch (e) {
      console.error('Markdown 내보내기 실패:', e);
      UI.toast('내보내기에 실패했습니다.', 'error');
    }
  }

  async function exportFullBackup() {
    if(Workspace.isDirty()&&!await _savePage({silent:true}))return;
    return Recovery.backup().catch(Safe.report);
  }

  /* =========================================================
     에디터 변경 시: 되돌리기 기록 + 본문→사이드바 즉시 순서 동기화
     (한 번의 save() 결과를 공유해 중복 직렬화를 피함)
  ========================================================= */
  async function _onEditorChanged(event) {
    const id=Workspace.getCurrentPageId(),ed=EditorManager.instance;
    if(!id||!ed||History.isApplying())return;
    try{const data=await EditorManager.getEditorData();if(id!==Workspace.getCurrentPageId()||ed!==EditorManager.instance||!data)return;if(!event?.detail?.fromHistory)History.record(data);}
    catch(e){Safe.report(e);}
  }

  /* =========================================================
     하위 페이지(형제) 순서 변경 (요구사항 3 — 사이드바 → 본문 양방향)
  ========================================================= */
  async function reorderChildren(parentId,newOrder){
    if(Workspace.isDirty()&&!await _savePage({silent:true}))return false;
    try{await Workspace.reorderChildrenStored(parentId,newOrder);Sidebar.render();if(parentId===Workspace.getCurrentPageId())await navigateToPage(parentId,{force:true});return true;}catch(e){Safe.report(e);return false;}
  }

  /* 형제 중 위로(-1)/아래로(+1) 한 칸 이동 */
  async function moveChildPage(childId, direction) {
    const meta = Workspace.getPageMeta(childId);
    if (!meta || !meta.parentId) return false;
    const ids = Workspace.getChildrenIds(meta.parentId);
    const idx = ids.indexOf(childId);
    const target = idx + (direction < 0 ? -1 : 1);
    if (idx === -1 || target < 0 || target >= ids.length) return false;
    [ids[idx], ids[target]] = [ids[target], ids[idx]];
    await reorderChildren(meta.parentId, ids);
    return true;
  }

  /* =========================================================
     PUBLIC API
  ========================================================= */
  return {
    start,
    save:_savePage,
    captureSnapshot:_captureSnapshot,
    reloadCurrent:async()=>{const id=Workspace.getCurrentPageId();if(!id)return;Workspace.markClean(id);return navigateToPage(id,{force:true});},
    navigateToPage,
    createNewPage,
    reorderChildren,
    moveChildPage,
    duplicatePage,
    exportPageMarkdown,
    exportFullBackup,
    showWelcome,
  };
})();

/* =========================================================
   앱 시작
========================================================= */
document.addEventListener('DOMContentLoaded', () => {
  App.start();
});
