/**
 * sidebar.js — 사이드바 렌더링 및 이벤트 처리
 */

const Sidebar = (() => {

  let _rootLimit=100;
  let _bound=false,_searchSeq=0,_searchTimer=null;
  let _expandedIds = new Set();
  let _dragId = null;        // 드래그 중인 페이지 id (요구사항 3)
  let _dragParent = null;    // 드래그 중인 페이지의 부모 id (루트면 null) — 같은 그룹끼리만 재배치

  /* =========================================================
     초기화
  ========================================================= */
  function init() {
    _expandedIds = new Set(Workspace.loadExpandedFromLocal());
    _bindEvents();
    render();
  }

  function _bindEvents() {
    if(_bound)return;_bound=true;
    // 새 페이지 버튼
    document.getElementById('btn-new-page')?.addEventListener('click', () => App.createNewPage());
    document.getElementById('btn-welcome-new-page')?.addEventListener('click', () => App.createNewPage());

    // 전체 백업(JSON) 버튼 (요구사항 5)
    document.getElementById('btn-backup')?.addEventListener('click', () => App.exportFullBackup());

    // 검색
    const searchInput = document.getElementById('search-input');
    searchInput?.addEventListener('input', () => {
      const q = searchInput.value.trim();
      clearTimeout(_searchTimer);_searchSeq++;_searchTimer=setTimeout(()=>renderSearch(q),200);
    });
    searchInput?.addEventListener('search', () => {
      if (!searchInput.value) render();
    });
  }

  /* =========================================================
     전체 사이드바 렌더링
  ========================================================= */
  function render() {
    const q=document.getElementById('search-input')?.value.trim();if(q){renderSearch(q);return;}
    renderFavorites();
    renderPageTree();
  }

  /* =========================================================
     즐겨찾기 섹션
  ========================================================= */
  function renderFavorites() {
    const section = document.getElementById('favorites-section');
    const list    = document.getElementById('favorites-list');
    if (!section || !list) return;

    const favorites = Workspace.getFavorites();

    if (!favorites.length) {
      section.classList.add('hidden');
      return;
    }

    section.classList.remove('hidden');
    list.innerHTML = '';

    favorites.forEach(meta => {
      const li = _createNavItem(meta, 0, true);
      list.appendChild(li);
    });
  }

  /* =========================================================
     페이지 트리
  ========================================================= */
  function renderPageTree() {
    const list = document.getElementById('pages-list');
    if (!list) return;

    const rootPages = Workspace.getRootPages();

    if (!rootPages.length) {
      list.innerHTML = '<li class="nav-empty">페이지가 없습니다</li>';
      return;
    }

    list.innerHTML = '';
    const currentId = Workspace.getCurrentPageId();
    const activePath=new Set([Workspace.getCurrentPageId(),...Workspace.getAncestors(Workspace.getCurrentPageId()).map(m=>m.id)]);
    rootPages.filter((m,i)=>i<_rootLimit||activePath.has(m.id)).forEach(meta => {
      const li = _createNavItemTree(meta, 0, currentId);
      list.appendChild(li);
    });
    if(rootPages.length>_rootLimit){const more=document.createElement('button');more.textContent='문서 더 보기 ('+rootPages.length+'개)';more.onclick=()=>{_rootLimit+=100;renderPageTree();};list.append(more);}
  }

  function _createNavItemTree(meta, depth, currentId) {
    if(depth>50){const warning=document.createElement('li');warning.textContent='계층 진단이 필요합니다';return warning;}
    const children = Workspace.getChildren(meta.id);
    const isExpanded = _expandedIds.has(meta.id);
    const isActive   = meta.id === currentId;

    const li = document.createElement('li');
    li.className = `nav-item${isExpanded ? ' expanded' : ''}`;
    li.setAttribute('data-depth', depth);
    li.setAttribute('data-page-id', meta.id);

    // Row
    const row = document.createElement('div');
    row.className = `nav-item-row${isActive ? ' active' : ''}`;

    // Expand button
    const expandBtn = document.createElement('button');
    expandBtn.className = 'nav-expand-btn';
    expandBtn.setAttribute('aria-label', isExpanded ? '접기' : '펼치기');
    expandBtn.innerHTML = children.length
      ? `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>`
      : `<span style="width:12px;height:12px;display:inline-block;"></span>`;

    if (children.length) {
      expandBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        _toggleExpand(meta.id, li);
      });
    }

    // Icon
    const iconEl = document.createElement('span');
    iconEl.className = 'nav-item-icon';
    iconEl.textContent = meta.icon || '📄';

    // Title
    const titleEl = document.createElement('span');
    titleEl.className = 'nav-item-title';
    titleEl.textContent = meta.title || '제목 없음';
    titleEl.title = meta.title || '제목 없음';

    // More button
    const moreBtn = document.createElement('button');
    moreBtn.className = 'nav-item-more';
    moreBtn.setAttribute('aria-label', '더보기');
    moreBtn.innerHTML = `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>`;

    const ctxOpts = { allowReorder: true };   // 루트/하위 모두 위·아래 이동 허용(같은 그룹 내)

    moreBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      _openContextMenu(e, meta, ctxOpts);
    });

    // 클릭으로 페이지 이동
    row.tabIndex=0;row.setAttribute('role','button');row.setAttribute('aria-label',meta.title||'제목 없음');
    row.addEventListener('keydown',e=>{if(e.target!==row)return;if(e.key==='Enter'||e.key===' '){e.preventDefault();App.navigateToPage(meta.id);}else if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){e.preventDefault();const r=row.getBoundingClientRect();_openContextMenu({clientX:r.left,clientY:r.bottom},meta,{allowReorder:true});}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const rows=Array.from(document.querySelectorAll('.nav-item-row')).filter(x=>x.getClientRects().length);rows[rows.indexOf(row)+(e.key==='ArrowDown'?1:-1)]?.focus();}else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){const li=row.closest('li');if(li.querySelector('.nav-children')&&_expandedIds.has(meta.id)!==(e.key==='ArrowRight')){_toggleExpand(meta.id,li);}}});
    row.addEventListener('click', () => App.navigateToPage(meta.id));

    // 우클릭 컨텍스트 메뉴
    row.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      _openContextMenu(e, meta, ctxOpts);
    });

    row.appendChild(expandBtn);
    row.appendChild(iconEl);
    row.appendChild(titleEl);
    row.appendChild(moreBtn);
    li.appendChild(row);

    // 드래그&드롭으로 순서 변경 (루트는 루트끼리, 하위는 같은 부모의 형제끼리만)
    _makeDraggable(li, row, meta);

    // Children
    if (children.length) {
      const childrenEl = document.createElement('ul');
      childrenEl.className = 'nav-children nav-list';

      if (isExpanded) {
        children.forEach(child => {
          const childLi = _createNavItemTree(child, depth + 1, currentId);
          childrenEl.appendChild(childLi);
        });
      }

      li.appendChild(childrenEl);
    }

    return li;
  }

  /* =========================================================
     드래그&드롭 순서 변경 (요구사항 3)
     - 루트는 루트끼리(rootPageOrder), 하위는 같은 부모의 형제끼리만.
       서로 다른 그룹(부모가 다른 항목) 위에는 드롭 표시/적용을 하지 않음 → 순서 정보가 꼬이지 않음.
  ========================================================= */
  function _clearDropMarkers() {
    document.querySelectorAll('.nav-item.drop-before, .nav-item.drop-after')
      .forEach(el => el.classList.remove('drop-before', 'drop-after'));
  }

  function _sameGroup(meta) { return (meta.parentId || null) === _dragParent; }

  function _makeDraggable(li, row, meta) {
    row.setAttribute('draggable', 'true');

    row.addEventListener('dragstart', (e) => {
      _dragId = meta.id;
      _dragParent = meta.parentId || null;
      li.classList.add('nav-dragging');
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', meta.id); } catch {}
      }
    });

    row.addEventListener('dragend', () => {
      _dragId = null; _dragParent = null;
      li.classList.remove('nav-dragging');
      _clearDropMarkers();
    });

    li.addEventListener('dragover', (e) => {
      if (_dragId == null || _dragId === meta.id || !_sameGroup(meta)) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
      const rect = row.getBoundingClientRect();
      const after = (e.clientY - rect.top) > rect.height / 2;
      _clearDropMarkers();
      li.classList.add(after ? 'drop-after' : 'drop-before');
    });

    li.addEventListener('dragleave', (e) => {
      if (!li.contains(e.relatedTarget)) li.classList.remove('drop-before', 'drop-after');
    });

    li.addEventListener('drop', async (e) => {
      if (_dragId == null || _dragId === meta.id || !_sameGroup(meta)) return;
      e.preventDefault();
      e.stopPropagation();
      const after = li.classList.contains('drop-after');
      const draggedId = _dragId;
      const parent = _dragParent;
      _clearDropMarkers();

      if (parent == null) {
        // 루트끼리
        let beforeId = meta.id;
        if (after) {
          const roots = Workspace.getRootPages();
          const idx = roots.findIndex(r => r.id === meta.id);
          beforeId = (idx >= 0 && roots[idx + 1]) ? roots[idx + 1].id : null;
        }
        await Workspace.reorderRootPage(draggedId, beforeId);
        render();
      } else {
        // 같은 부모의 형제끼리
        const ids = Workspace.getChildrenIds(parent).filter(id => id !== draggedId);
        const i = ids.indexOf(meta.id);
        ids.splice(after ? i + 1 : i, 0, draggedId);
        await App.reorderChildren(parent, ids);
      }
    });
  }

  /* =========================================================
     즐겨찾기 전용 아이템 (단순)
  ========================================================= */
  function _createNavItem(meta, depth, isFavorite = false) {
    const li = document.createElement('li');
    li.className = 'nav-item';
    li.setAttribute('data-depth', depth);
    li.setAttribute('data-page-id', meta.id);

    const row = document.createElement('div');
    row.className = `nav-item-row${meta.id === Workspace.getCurrentPageId() ? ' active' : ''}`;
    row.style.paddingLeft = `${8 + depth * 16}px`;

    const iconEl = document.createElement('span');
    iconEl.className = 'nav-item-icon';
    iconEl.textContent = meta.icon || '📄';

    const titleEl = document.createElement('span');
    titleEl.className = 'nav-item-title';
    titleEl.textContent = meta.title || '제목 없음';

    row.appendChild(iconEl);
    row.appendChild(titleEl);
    row.tabIndex=0;row.setAttribute('role','button');row.setAttribute('aria-label',meta.title||'제목 없음');
    row.addEventListener('keydown',e=>{if(e.target!==row)return;if(e.key==='Enter'||e.key===' '){e.preventDefault();App.navigateToPage(meta.id);}else if(e.key==='ContextMenu'||(e.shiftKey&&e.key==='F10')){e.preventDefault();const r=row.getBoundingClientRect();_openContextMenu({clientX:r.left,clientY:r.bottom},meta,{allowReorder:true});}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const rows=Array.from(document.querySelectorAll('.nav-item-row')).filter(x=>x.getClientRects().length);rows[rows.indexOf(row)+(e.key==='ArrowDown'?1:-1)]?.focus();}else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){const li=row.closest('li');if(li.querySelector('.nav-children')&&_expandedIds.has(meta.id)!==(e.key==='ArrowRight')){_toggleExpand(meta.id,li);}}});
    row.addEventListener('click', () => App.navigateToPage(meta.id));
    row.addEventListener('contextmenu', (e) => { e.preventDefault(); _openContextMenu(e, meta); });

    li.appendChild(row);
    return li;
  }

  /* =========================================================
     펼침/접힘 토글
  ========================================================= */
  function _toggleExpand(pageId, liEl) {
    const isExpanded = _expandedIds.has(pageId);

    if (isExpanded) {
      _expandedIds.delete(pageId);
      liEl.classList.remove('expanded');
      const childrenEl = liEl.querySelector('.nav-children');
      if (childrenEl) childrenEl.innerHTML = '';
    } else {
      _expandedIds.add(pageId);
      liEl.classList.add('expanded');
      const childrenEl = liEl.querySelector('.nav-children');
      const currentId  = Workspace.getCurrentPageId();

      if (childrenEl) {
        const children = Workspace.getChildren(pageId);
        const depth    = parseInt(liEl.getAttribute('data-depth') || '0');
        children.forEach(child => {
          const childLi = _createNavItemTree(child, depth + 1, currentId);
          childrenEl.appendChild(childLi);
        });
      }
    }

    // localStorage에 저장
    Workspace.setExpandedPages([..._expandedIds]);
  }

  /* =========================================================
     컨텍스트 메뉴
  ========================================================= */
  function _openContextMenu(e, meta, opts = {}) {
    const isFav = Workspace.isFavorite(meta.id);

    // 위로/아래로 이동 (요구사항 3): 루트는 루트끼리, 하위는 같은 부모 형제끼리
    const allowReorder = opts.allowReorder === true;
    const isRoot = !meta.parentId;
    const sibs = allowReorder ? (isRoot ? Workspace.getRootPages().map(p => p.id) : Workspace.getChildrenIds(meta.parentId)) : [];
    const sibIdx = sibs.indexOf(meta.id);

    UI.openContextMenu(e.clientX, e.clientY, {
      favorited: isFav,
      showMove:    allowReorder && sibs.length > 1,
      canMoveUp:   sibIdx > 0,
      canMoveDown: sibIdx >= 0 && sibIdx < sibs.length - 1,

      onMoveUp: async () => {
        if (isRoot) { if (await Workspace.moveRootPage(meta.id, -1)) render(); }
        else { await App.moveChildPage(meta.id, -1); }
      },
      onMoveDown: async () => {
        if (isRoot) { if (await Workspace.moveRootPage(meta.id, +1)) render(); }
        else { await App.moveChildPage(meta.id, +1); }
      },

      onDuplicate: async () => {
        await App.duplicatePage(meta.id);
      },

      onExport: async () => {
        await App.exportPageMarkdown(meta.id);
      },

      onRename: async () => {
        if(Workspace.isDirty()&&!await App.save({silent:true}))return;
        const newTitle = await UI.prompt('이름 바꾸기', meta.title || '제목 없음', '페이지 이름');
        if (newTitle) {
          await Workspace.renamePage(meta.id, newTitle);
          // 현재 페이지라면 제목도 업데이트
          if (meta.id === Workspace.getCurrentPageId()) {
            const titleInput = document.getElementById('page-title-input');
            if (titleInput) titleInput.textContent = newTitle;
          }
          if(meta.id===Workspace.getCurrentPageId())await App.reloadCurrent();
          render();
        }
      },

      onFavorite: async () => {
        const nowFav = await Workspace.toggleFavorite(meta.id);
        UI.toast(nowFav ? '즐겨찾기에 추가했습니다.' : '즐겨찾기에서 제거했습니다.', 'success');
        render();
      },

      onNewSubpage: async () => {
        const result = await App.createNewPage(meta.id);
        if (result) {
          // 부모 펼치기
          if (!_expandedIds.has(meta.id)) {
            const liEl = document.querySelector(`[data-page-id="${meta.id}"]`);
            if (liEl) _toggleExpand(meta.id, liEl);
          }
          render();
        }
      },

      onDelete: async () => {
        const hasChildren = Workspace.getChildren(meta.id).length > 0;
        const confirmed = await UI.confirmDelete(meta.title || '제목 없음', hasChildren);
        if (!confirmed) return;

        if(Workspace.isDirty()&&!await App.save({silent:true}))return;
        const currentId = Workspace.getCurrentPageId();
        const parentId  = meta.parentId;   // 삭제 전에 부모 기록
        await Workspace.deletePage(meta.id);

        render();

        // 현재 페이지가 삭제됐으면 Welcome 화면으로
        if (currentId === meta.id) {
          App.showWelcome();
        }

        UI.toast('휴지통으로 이동했습니다. 보관함에서 복구할 수 있습니다.', 'info');
      },
    });
  }

  /* =========================================================
     검색
  ========================================================= */
  async function renderSearch(query){
    const seq=++_searchSeq,list=document.getElementById('pages-list');if(!list)return;
    if(!query){render();return;}document.getElementById('favorites-section')?.classList.add('hidden');list.textContent='본문까지 검색 중…';
    try{const results=await Workspace.searchPages(query,{cancelled:()=>seq!==_searchSeq});if(seq!==_searchSeq)return;list.replaceChildren();if(!results.length){list.textContent='검색 결과가 없습니다';return;}
      const append=(start=0)=>{const fragment=document.createDocumentFragment();for(const meta of results.slice(start,start+100)){const li=document.createElement('li');li.className='search-result-item';li.tabIndex=0;li.setAttribute('role','button');const icon=document.createElement('span');icon.textContent=meta.icon||'📄';const title=document.createElement('span');title.className='search-result-title';const text=meta.title||'제목 없음';let offset=0,at;while((at=text.toLocaleLowerCase().indexOf(query.toLocaleLowerCase(),offset))>=0){title.append(document.createTextNode(text.slice(offset,at)));const mark=document.createElement('mark');mark.textContent=text.slice(at,at+query.length);title.append(mark);offset=at+query.length;}title.append(document.createTextNode(text.slice(offset)));li.append(icon,title);const go=()=>{document.getElementById('search-input').value='';_searchSeq++;App.navigateToPage(meta.id);render();};li.onclick=go;li.onkeydown=e=>{if(e.key==='Enter')go();};fragment.append(li);}list.append(fragment);if(start+100<results.length){const more=document.createElement('button');more.textContent='검색 결과 더 보기';more.onclick=()=>{more.remove();append(start+100);};list.append(more);}};append();
    }catch(e){if(seq===_searchSeq){list.textContent=e.message;}}
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /* =========================================================
     활성 페이지 표시 업데이트
  ========================================================= */
  function setActivePage(pageId) {
    document.querySelectorAll('.nav-item-row').forEach(row => {
      row.classList.remove('active');
    });
    const activeRow = document.querySelector(`[data-page-id="${pageId}"] > .nav-item-row`);
    if (activeRow) {
      activeRow.classList.add('active');
      activeRow.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }

  async function expandPage(pageId) {
    if (!pageId) return;
    _expandedIds.add(pageId);
    await Workspace.setExpandedPages([..._expandedIds]);
    render();
  }

  /* =========================================================
     PUBLIC API
  ========================================================= */
  return {
    init,
    render,
    renderFavorites,
    renderPageTree,
    setActivePage,
    expandPage,
    renderSearch,
  };
})();
