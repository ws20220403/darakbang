# Third-party notices

Exact v8 dependency versions are retained as unmodified local copies, with SHA-256 provenance and SHA-384 script integrity values.

| Package | Version | Declared license |
| --- | --- | --- |
| @editorjs/editorjs | 2.30.6 | Apache-2.0 |
| @editorjs/header | 2.8.7 | MIT |
| @editorjs/nested-list | 1.4.3 | MIT |
| @editorjs/checklist | 1.6.0 | MIT |
| @editorjs/code | 2.9.4 | MIT |
| @editorjs/delimiter | 1.4.2 | MIT |
| @editorjs/quote | 2.7.6 | MIT |
| @editorjs/inline-code | 1.5.1 | MIT |
| @editorjs/underline | 1.1.0 | MIT |

Original available license files are in `vendor/licenses/`. The published underline 1.1.0 package declares MIT in package.json but does not supply a LICENSE, LICENSE.md or LICENSE.txt file; the inspected upstream repository also has no LICENSE file. Its declaration and source remain in the manifest, with standard MIT text supplied separately and no invented upstream copyright notice.

Sources: [underline package](https://www.jsdelivr.com/package/npm/@editorjs/underline), [official repository](https://github.com/editor-js/underline). Exact package and license URLs for every dependency are in `vendor/licenses/manifest.json`.

Google Identity Services and Google Fonts are externally loaded, not redistributed here. Original application code and earlier changelogs retain the original project's ownership and terms. No new license is assigned to the user's original code.
